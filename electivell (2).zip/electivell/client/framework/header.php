<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

//--- Clear room and amenity sessions if nav button clicked
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if any nav button was clicked
    $navButtons = ['navHome', 'navBlogs', 'navRooms', 'navAmenities', 'navContact', 'navAbout'];
    foreach ($navButtons as $btn) {
        if (isset($_POST[$btn])) {
            unset($_SESSION['roomNumber']);
            unset($_SESSION['amenityNumber']);
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hotel Reservation</title>
    <link rel="stylesheet" href="../design/headerStyle.css">
</head>
<body>
    <header class="navbar">
        <div class="nav-left">
            <img src="bonsai800.jpg" alt="Hotel Logo" class="logo-img">
            <span class="site-title">Hotel La Maria</span>
        </div>

        <nav class="nav-right">
            <form action="amenity.php" method="POST" style="display:inline;">
                <button type="submit" name="navHome" class="nav-link">Home</button>
            </form>
            <form action="amenity.php" method="POST" style="display:inline;">
                <button type="submit" name="navBlogs" class="nav-link">Blogs</button>
            </form>
            <form action="room.php" method="POST" style="display:inline;">
                <button type="submit" name="navRooms" class="nav-link">Rooms</button>
            </form>
            <form action="amenity.php" method="POST" style="display:inline;">
                <button type="submit" name="navAmenities" class="nav-link">Amenities</button>
            </form>
            <form action="amenity.php" method="POST" style="display:inline;">
                <button type="submit" name="navContact" class="nav-link">Contact</button>
            </form>
            <form action="amenity.php" method="POST" style="display:inline;">
                <button type="submit" name="navAbout" class="nav-link">About</button>
            </form>
        </nav>
    </header>
</body>
</html>
