<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$roomNumber = $_SESSION['roomNumber'];
$amenityNumber = $_SESSION['amenityNumber'];

//--- MAP OF ALL AVAILABLE AMENITIES (DEFAULT DATA)
$amenityMap = [
    1 => [
        'title' => 'Mini Bar',
        'description' => 'Enjoy refreshments conveniently inside your room.',
        'price' => 25,
        'images' => [
            "../design/images/amenity1_1.jpg",
            "../design/images/amenity1_2.jpg",
            "../design/images/amenity1_3.jpg"
        ]
    ],
    2 => [
        'title' => 'Extra Bed',
        'description' => 'Perfect for additional guests staying overnight.',
        'price' => 40,
        'images' => [
            "../design/images/amenity2_1.jpg",
            "../design/images/amenity2_2.jpg",
            "../design/images/amenity2_3.jpg"
        ]
    ],
    3 => [
        'title' => 'Sea View',
        'description' => 'Enjoy a beautiful ocean view from your room.',
        'price' => 60,
        'images' => [
            "../design/images/amenity3_1.jpg",
            "../design/images/amenity3_2.jpg",
            "../design/images/amenity3_3.jpg"
        ]
    ],
    4 => [
        'title' => 'Room Service',
        'description' => 'Order food and services directly to your room.',
        'price' => 30,
        'images' => [
            "../design/images/amenity4_1.jpg",
            "../design/images/amenity4_2.jpg",
            "../design/images/amenity4_3.jpg"
        ]
    ],
    5 => [
        'title' => 'Breakfast Included',
        'description' => 'Daily breakfast included with your stay.',
        'price' => 20,
        'images' => [
            "../design/images/amenity5_1.jpg",
            "../design/images/amenity5_2.jpg",
            "../design/images/amenity5_3.jpg"
        ]
    ]
];

//--- SELECT CURRENT AMENITY
$amenityData = $amenityMap[$amenityNumber] ?? $amenityMap[1];

//--- WHEN ADD AMENITY IS CLICKED, REDIRECT BACK TO ROOM DETAILS
if (isset($_POST['add-amenity']) && isset($_SESSION['roomNumber'])) {
    $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];
    $_SESSION['amenityNumber'] = (int)$_POST['amenityNumber'];
    header("Location: roomDetails.php?");
    exit;
}

//--- HEADER OF THE HOME PAGE
include("header.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $amenityData['title'] ?> Details</title>
    <link rel="stylesheet" href="../design/amenityDetailStyle.css">
</head>

<body>
    <h1><?= $amenityData['title'] ?></h1>

    <!-- AMENITY IMAGES -->
    <div class="amenity-images">
        <?php foreach ($amenityData['images'] as $img): ?>
            <img src="<?= $img ?>" alt="Amenity Image">
        <?php endforeach; ?>
    </div>

    <!-- AMENITY DETAILS -->
    <div class="amenity-details">
        <h2>Description</h2>
        <p><?= $amenityData['description'] ?></p>

        <h2>Price</h2>
        <p>$<?= number_format($amenityData['price'], 2) ?></p>

        <div class="buttons">
            <?php if (isset($_SESSION['roomNumber'])): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="roomNumber" value="<?= $_SESSION['roomNumber'] ?>">
                    <button type="submit" name="add-amenity" class="add-amenity"> Add Amenity </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>

<!-- FOOTER OF THE HOME PAGE -->
<?php include("footer.html"); ?>