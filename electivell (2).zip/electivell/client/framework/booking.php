<?php
session_start();

// --- Get room info and selected amenities from session
$roomType = $_SESSION['roomType'] ?? ($_POST['room_type'] ?? 'Deluxe Room');
$extraAmenities = $_SESSION['addedAmenity'] ?? ($_POST['amenities'] ?? []);

// --- Store room info and selected amenities in session
$_SESSION['roomType'] = $roomType;
$_SESSION['addedAmenity'] = $extraAmenities;

// --- Free amenities always included
$freeAmenities = ['Free Wi-Fi'];

// --- HANDLE FORM SUBMISSION FOR PROCEED TO PAYMENT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fullname'])) {

    // Collect guest information from POST
    $guestName    = $_POST['fullname'];
    $guestEmail   = $_POST['email'];
    $guestPhone   = $_POST['phone'];
    $guestDOB     = $_POST['dob'];
    $guestAddress = $_POST['address'];
    $guestCount   = (int)$_POST['guests'];

    // --- COMMENT: INSERT GUEST INFORMATION AND BOOKING DATA INTO DATABASE
    /*
    $sql = "INSERT INTO bookings (room_type, guests, fullname, email, phone, dob, address, amenities)
            VALUES (:room_type, :guests, :fullname, :email, :phone, :dob, :address, :amenities)";
    // Execute using prepared statements and bind the values accordingly
    */

    // --- Redirect to payment page after processing
    header("Location: payment.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Your Stay</title>
    <link rel="stylesheet" href="../design/bookingStyle.css">
</head>
<body>

<div class="reservation-container">

    <h2>Book Your Stay</h2>

    <form method="POST">

        <!-- GUEST INFORMATION -->
        <section class="card">
            <h3>Guest Information</h3>

            <label>Full Name</label>
            <input type="text" name="fullname" required>

            <label>Email Address</label>
            <input type="email" name="email" required>

            <label>Phone Number</label>
            <input type="text" name="phone" required>

            <label>Date of Birth</label>
            <input type="date" name="dob">

            <label>Address</label>
            <textarea name="address"></textarea>

            <label>Number of Guests</label>
            <input type="number" name="guests" min="1" max="10" value="2" required>
        </section>

        <!-- BOOKING DETAILS -->
        <section class="card">
            <h3>Booking Details</h3>

            <p><strong>Room Selected:</strong> <?= htmlspecialchars($roomType) ?></p>

            <hr>

            <!-- FREE AMENITY -->
            <p><strong>Included Amenities:</strong></p>
            <ul>
                <?php foreach ($freeAmenities as $amenity): ?>
                    <li><?= htmlspecialchars($amenity) ?></li>
                <?php endforeach; ?>
            </ul>

            <!-- ADDITIONAL AMENITY -->
            <?php if (!empty($extraAmenities)): ?>
                <hr>
                <p><strong>Additional Amenities:</strong></p>
                <ul>
                    <?php foreach ($extraAmenities as $amenity): ?>
                        <li><?= htmlspecialchars($amenity) ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>

        <!-- HIDDEN VALUES PASSED TO PAYMENT PAGE -->
        <input type="hidden" name="room_type" value="<?= htmlspecialchars($roomType) ?>">
        <?php foreach ($extraAmenities as $amenity): ?>
            <input type="hidden" name="amenities[]" value="<?= htmlspecialchars($amenity) ?>">
        <?php endforeach; ?>

        <!-- BUTTON -->
        <button type="submit" class="primary-btn">
            Proceed to Payment
        </button>

    </form>

</div>

</body>
</html>
