<!-- HEADER OF THE HOME PAGE -->
<?php include("header.php"); ?>

<!-- HTML MARKUP -->
<!DOCTYPE html>
<html lang="en">

<!-- HEADER OF THE HOME PAGE -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../design/roomStyle.css">
</head>

<!-- BODY OF THE PAGE -->
<body>

    <!-- SCROLLABLE ROOM IN THE HOMEPAGE -->
    <div class="room-scroll">
        
    <!-- ADDS ON PHP LOOPING LOGIC -->
        <?php
            for ($i = 1; $i <= 10; $i++) 
            {
                renderRoomCard($i);
            }
        ?>
    </div>
</body>

<!-- END OF HE HTML MARK UP -->
</html>

<!-- PHP FUNCTION LIST -->
<?php

//--- FUNCTION FOR EVERY ROOM CARD IN THE SCROLLABLE AREA
function renderRoomCard(int $roomNumber)
{
    //--- WHEN THE VIEW DETAILS IS CLICKED, REDIRECT IT TO THE ROOM DATAILS PAGE
    if (isset($_POST['view-details']))
    {
        $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];
        unset($_SESSION['amenityNumber']);
        header("Location: roomDetails.php");
        exit;
    }

    ?>

    <div class="room-card">
        <div class="room-images">
            <img src="../design/images/room<?= $roomNumber ?>_1.jpg" alt="Room image">
            <img src="../design/images/room<?= $roomNumber ?>_2.jpg" alt="Room image">
            <img src="../design/images/room<?= $roomNumber ?>_3.jpg" alt="Room image">
        </div>

        <h3>Room <?= $roomNumber ?></h3>

        <p class="room-desc">
            Comfortable room with modern amenities, perfect for relaxation.
        </p>

        <form method="post">
            <input type="hidden" name="roomNumber" value="<?= $roomNumber ?>">
            <button type="submit" name="view-details" class="room-btn">View Details</button>
        </form>
    </div>

    <?php
}

?>


<!-- FOOTER OF THE HOME PAGE -->
<?php include("footer.html"); ?>