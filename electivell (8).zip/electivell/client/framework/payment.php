<?php
// --- INCLUDE ADMIN DATABASE
include("dbInclude.php");

if (!isset($_SESSION['guestInfo'])) {
    header("Location: booking.php");
    exit;
}

$guest = $_SESSION['guestInfo'];
$roomType = $_SESSION['roomType'] ?? 'Deluxe';
$extraAmenities = $_SESSION['addedAmenity'] ?? [];

$freeAmenities = ['Free Wi-Fi'];

/*
    FUTURE DATABASE INTEGRATION NOTE:
    This page currently pulls data from SESSION.
    Later, replace this with a database SELECT query using booking_id.
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Slip</title>
    <link rel="stylesheet" href="../design/bookingStyle.css">
</head>
<body>

<section class="reserve-hero">
    <h1>Payment Summary</h1>
    <p>Please review your reservation details.</p>
</section>

<section class="reserve-container">

<div class="reserve-card">

<h2>Guest Information</h2>

<p><strong>Name:</strong> <?= htmlspecialchars($guest['name']) ?></p>
<p><strong>Email:</strong> <?= htmlspecialchars($guest['email']) ?></p>
<p><strong>Phone:</strong> <?= htmlspecialchars($guest['phone']) ?></p>
<p><strong>Date of Birth:</strong> <?= htmlspecialchars($guest['dob']) ?></p>
<p><strong>Age:</strong> <?= htmlspecialchars($guest['age']) ?></p>
<p><strong>Address:</strong> <?= htmlspecialchars($guest['address']) ?></p>
<p><strong>Guests:</strong> <?= htmlspecialchars($guest['guests']) ?></p>

<hr>

<h2>Room Details</h2>

<p><strong>Room Type:</strong> <?= htmlspecialchars($roomType) ?></p>

<p><strong>Included Amenities:</strong></p>
<ul>
<?php foreach ($freeAmenities as $amenity): ?>
    <li><?= htmlspecialchars($amenity) ?></li>
<?php endforeach; ?>
</ul>

<?php if (!empty($extraAmenities)): ?>
<p><strong>Additional Amenities:</strong></p>
<ul>
<?php foreach ($extraAmenities as $amenity): ?>
    <li><?= htmlspecialchars($amenity) ?></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<hr>

<h2>Payment Method</h2>
<p><strong>Selected Payment:</strong> <?= htmlspecialchars($guest['payment']) ?></p>

<hr>

<button class="confirm-btn" onclick="window.print()">
    Print Payment Slip
</button>

</div>

</section>

</body>
</html>
