<?php
// ===============================
// CONTACT.PHP
// ===============================

include("header.php");

// Initialize variables
$name = '';
$email = '';
$message = '';
$success = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';

    if (empty($name) || empty($email) || empty($message)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {

        $safe_name = htmlspecialchars($name);
        $safe_email = htmlspecialchars($email);
        $safe_message = htmlspecialchars($message);

        $to = "hlmaria08@gmail.com";
        $subject = "New Contact Message from $safe_name";
        $body = "Name: $safe_name\nEmail: $safe_email\n\nMessage:\n$safe_message";
        $headers = "From: $safe_email\r\nReply-To: $safe_email\r\n";

        if (mail($to, $subject, $body, $headers)) {
            $success = "Your message has been sent successfully!";
            $name = $email = $message = '';
        } else {
            $error = "Message failed to send.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Hotel La Maria</title>
    <link rel="stylesheet" href="../design/contactStyle.css">
</head>

<body>

<!-- CONTACT HERO -->
<section class="contact-hero">
    <h1 class="contact-title">Contact Hotel La Maria</h1>

    <div class="contact-subtitle">
        We would love to hear from you
    </div>

    <div class="contact-container">

        <div class="contact-info">
            <h3>Contact Details</h3>
            <p><strong>Address:</strong> Barangay 04, Guiuan, Eastern Samar</p>
            <p><strong>Phone:</strong> +63 906 243 8933</p>
            <p><strong>Email:</strong> hlmaria08@gmail.com</p>
        </div>

        <form class="contact-form" method="POST" action="">
            
            <div class="input-wrapper">
                <input type="text" name="name" required
                    value="<?php echo htmlspecialchars($name); ?>" placeholder=" ">
                <label>Your Name</label>
            </div>

            <div class="input-wrapper">
                <input type="email" name="email" required
                    value="<?php echo htmlspecialchars($email); ?>" placeholder=" ">
                <label>Your Email</label>
            </div>

            <div class="input-wrapper">
                <textarea name="message" rows="5" required placeholder=" "><?php echo htmlspecialchars($message); ?></textarea>
                <label>Your Message</label>
            </div>

            <button type="submit" class="contact-btn">Send Message</button>

            <?php if (!empty($success)) : ?>
                <p class="form-success"><?php echo $success; ?></p>
            <?php endif; ?>

            <?php if (!empty($error)) : ?>
                <p class="form-error"><?php echo $error; ?></p>
            <?php endif; ?>

        </form>

    </div>
</section>

</body>
</html>

<?php include("footer.html"); ?>
