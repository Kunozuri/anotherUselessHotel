<?php
// --- INCLUDE HEADER OF THE HOME PAGE
include("header.php");

// --- SESSION CHECK (CLEAN VERSION)
if (!isset($_SESSION['roomNumber']) || empty($_SESSION['roomNumber'])) {
    // --- USER IS NOT IN BOOKING WORKFLOW
    unset($_SESSION['addedAmenities']);
    unset($_SESSION['lastRoomNumber']);
    $roomId = null;
} else {
    // --- SET CURRENT ROOM ID
    $roomId = (int)$_SESSION['roomNumber'];

    // --- INITIALIZE ADDED AMENITIES ARRAY IF NOT SET
    if (!isset($_SESSION['addedAmenities'])) {
        $_SESSION['addedAmenities'] = [];
    }

    // --- INITIALIZE LAST ROOM NUMBER IF NOT SET
    if (!isset($_SESSION['lastRoomNumber'])) {
        $_SESSION['lastRoomNumber'] = $roomId;
    }

    // --- RESET ADDED AMENITIES IF USER SWITCHED ROOMS
    if ($_SESSION['lastRoomNumber'] !== $roomId) {
        $_SESSION['addedAmenities'][$roomId] = [];
    }

    // --- UPDATE LAST VISITED ROOM
    $_SESSION['lastRoomNumber'] = $roomId;
}

// --- SESSION VARIABLES
$roomNumber = $_SESSION['roomNumber'] ?? null;
$amenityNumber = $_SESSION['amenityNumber'] ?? null;

// --- FETCH CURRENT AMENITY FROM DATABASE
if ($amenityNumber) {
    $amenityData = $db->fetchWhere('amenities', ['amenity_id' => $amenityNumber]);
    $amenityData = $amenityData[0] ?? null;

    if ($amenityData) {
        // --- FETCH ALL IMAGES FOR THIS AMENITY
        $amenityImages = $db->fetchWhere('amenity_images', ['amenity_id' => $amenityNumber]);
        // --- SORT IMAGES SO PRIMARY IMAGE COMES FIRST
        usort($amenityImages, function ($a, $b) {
            return $b['is_primary'] <=> $a['is_primary'];
        });
        $amenityData['images'] = array_column($amenityImages, 'image_path');
    }
}

// --- FALLBACK IF AMENITY NOT FOUND
if (!$amenityData) {
    die("Amenity not found.");
}

// --- HANDLE ADD AMENITY BUTTON CLICK
if (isset($_POST['add-amenity']) && isset($_SESSION['roomNumber'])) {
    $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];

    // --- ENSURE ROOM-SPECIFIC ADDED AMENITIES ARRAY EXISTS
    if (!isset($_SESSION['addedAmenities'][$roomId])) {
        $_SESSION['addedAmenities'][$roomId] = [];
    }

    // --- AVOID DUPLICATES AND ADD AMENITY TO SESSION
    if (!in_array($amenityNumber, $_SESSION['addedAmenities'][$roomId])) {
        $_SESSION['addedAmenities'][$roomId][] = $amenityNumber;
    }

    // --- REDIRECT BACK TO ROOM DETAILS PAGE
    header("Location: roomDetails.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- --- PAGE META CHARSET -->
    <meta charset="UTF-8">
    <!-- --- PAGE TITLE -->
    <title><?= htmlspecialchars($amenityData['amenity_name']) ?> Details</title>
    <!-- --- LINK STYLESHEET -->
    <link rel="stylesheet" href="../design/amenityDetailStyle.css">
</head>

<body>

<!-- --- AMENITY NAME HEADING -->
<h1><?= htmlspecialchars($amenityData['amenity_name']) ?></h1>

<!-- --- AMENITY IMAGES -->
<div class="amenity-images">
    <?php foreach ($amenityData['images'] as $img): ?>
        <img src="/electivell/admin/<?= htmlspecialchars($img) ?>" alt="Amenity Image">
    <?php endforeach; ?>
</div>

<!-- --- AMENITY DETAILS SECTION -->
<div class="amenity-details">

    <!-- --- AMENITY DESCRIPTION -->
    <h2>Description</h2>
    <p><?= htmlspecialchars($amenityData['description']) ?></p>

    <!-- --- AMENITY PRICE -->
    <h2>Price</h2>
    <p>$<?= number_format($amenityData['price'], 2) ?></p>

    <!-- --- ACTION BUTTONS -->
    <div class="buttons">
        <?php if (isset($_SESSION['roomNumber'])): ?>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="roomNumber" value="<?= (int)$_SESSION['roomNumber'] ?>">
                <!-- --- ADD AMENITY BUTTON -->
                <button type="submit" name="add-amenity" class="add-amenity"> Add Amenity </button>
            </form>
        <?php endif; ?>
    </div>
</div>

</body>
</html>

<!-- --- INCLUDE FOOTER FILE -->
<?php include("footer.html"); ?>