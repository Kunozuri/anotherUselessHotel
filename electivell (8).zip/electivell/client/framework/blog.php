<?php include("header.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel La Maria Blog</title>
    <link rel="stylesheet" href="../design/blogStyle.css">
</head>

<body>

<!-- BLOG HERO -->
<section class="blog-hero">
    <h1 class="blog-title">Hotel La Maria Blog</h1>

    <div class="blog-subtitle">
        A Complete Guide to Staying at Hotel La Maria
    </div>

    <div class="blog-image">
        <img src="../../assets/632090744.jpg" alt="Hotel La Maria">
    </div>

    <p class="blog-intro">
        At Hotel La Maria, every stay is designed to feel calm, elegant, and refreshing.
        Located near soft white-sand beaches and surrounded by pastel-colored sunsets, our resort
        gives guests a peaceful escape from busy city life. From the moment guests arrive, they
        are welcomed by a warm atmosphere, stylish interiors, and a staff that focuses on comfort
        and hospitality.
    </p>
</section>

</body>
</html>

<?php include("footer.html"); ?>
