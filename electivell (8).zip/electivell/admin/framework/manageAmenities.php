<?php
// --- INCLUDE ADMIN DATABASE (USED FOR SESSION & SIDEBAR)
include("dbInclude.php");

// --- AUTHENTICATION PROTECTION (REDIRECT IF NOT LOGGED IN)
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- HANDLE DELETE AMENITY IF FORM SUBMITTED
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_amenity_id'])) {

    // --- GET AMENITY ID TO DELETE
    $amenityId = (int) $_POST['delete_amenity_id'];

    // --- FETCH ALL IMAGES RELATED TO THIS AMENITY
    $amenityImages = $db->fetchWhere('amenity_images', ['amenity_id' => $amenityId]);

    if ($amenityImages) {
        foreach ($amenityImages as $image) {

            // --- DELETE IMAGE FILE FROM SERVER STORAGE
            $filePath = __DIR__ . "/../" . $image['image_path'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }

        // --- DELETE IMAGE RECORDS FROM DATABASE
        $db->deleteWhere('amenity_images', ['amenity_id' => $amenityId]);
    }

    // --- DELETE AMENITY RECORD FROM DATABASE
    $db->deleteWhere('amenities', ['amenity_id' => $amenityId]);

    // --- REDIRECT TO PREVENT FORM RESUBMISSION
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// --- GET ADMIN NAME FROM SESSION
$adminName = $_SESSION['adminName'] ?? "Admin";

// --- FETCH ALL AMENITIES WITH LEFT JOIN ON PRIMARY IMAGE
$amenities = $db->fetchJoin(
    'amenities a',
    [
        [
            'type' => 'LEFT',
            'table' => 'amenity_images ai',
            'on' => 'a.amenity_id = ai.amenity_id AND ai.is_primary = 1',
            'select' => ['image' => 'ai.image_path']
        ]
    ],
    [],
    'AND',
    'a.amenity_id DESC'
);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- PAGE META DATA -->
    <meta charset="UTF-8">
    <title>Manage Amenities</title>

    <!-- STYLESHEETS -->
    <link rel="stylesheet" href="../design/sidebarStyle.css">
    <link rel="stylesheet" href="../design/manageRoomsStyle.css">
</head>

<body class="admin-page">

    <!-- SIDEBAR INCLUDE -->
    <?php include("sidebar.php"); ?>

    <!-- MAIN CONTENT -->
    <main class="main-content">

        <section class="section-content">

            <!-- PAGE TITLE -->
            <h1>Manage Amenities</h1>

            <!-- ADD NEW AMENITY BUTTON -->
            <a href="addEditAmenity.php" class="action-btn">
                Add New Amenity
            </a>

            <!-- AMENITIES TABLE -->
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Active</th>
                        <th>Featured</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>

                    <!-- CHECK IF AMENITIES EXIST -->
                    <?php if (!empty($amenities)): ?>
                        <?php foreach ($amenities as $amenity): ?>
                            <tr>
                                <!-- AMENITY ID -->
                                <td><?= $amenity['amenity_id'] ?></td>

                                <!-- AMENITY NAME -->
                                <td><?= htmlspecialchars($amenity['amenity_name']) ?></td>

                                <!-- AMENITY PRICE -->
                                <td><?= number_format($amenity['price'], 2) ?></td>

                                <!-- AMENITY ACTIVE STATUS -->
                                <td><?= $amenity['is_active'] == 1 ? 'Yes' : 'No' ?></td>

                                <!-- AMENITY FEATURED STATUS -->
                                <td><?= $amenity['is_featured'] == 1 ? 'Yes' : 'No' ?></td>

                                <!-- AMENITY PRIMARY IMAGE -->
                                <td>
                                    <?php if (!empty($amenity['image'])): ?>
                                        <img src="../assets/amenities/<?= htmlspecialchars(basename($amenity['image'])) ?>" alt="Amenity Image">
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>

                                <!-- ACTION BUTTONS: EDIT & DELETE -->
                                <td>
                                    <!-- EDIT BUTTON -->
                                    <a href="addEditAmenity.php?id=<?= $amenity['amenity_id'] ?>" class="action-btn edit-btn">
                                        Edit
                                    </a>

                                    <!-- DELETE FORM BUTTON -->
                                    <form method="POST"
                                        style="display:inline;"
                                        onsubmit="return confirm('Are you sure you want to delete this amenity?');">

                                        <!-- HIDDEN AMENITY ID FOR DELETE -->
                                        <input type="hidden" name="delete_amenity_id" value="<?= $amenity['amenity_id'] ?>">

                                        <!-- DELETE BUTTON -->
                                        <button type="submit" class="action-btn delete-btn">
                                            Delete
                                        </button>

                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- NO AMENITIES FOUND -->
                        <tr>
                            <td colspan="8">No amenities found.</td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>

        </section>

    </main>
</body>

</html>