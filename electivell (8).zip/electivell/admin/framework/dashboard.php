<?php
// --- INCLUDE ADMIN DATABASE
include("dbInclude.php");

// --- AUTH PROTECTION (REQUIRED)
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- ADMIN NAME (SESSION ALREADY STARTED IN sidebar.php)
$adminName = $_SESSION['adminName'] ?? "Admin";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../design/dashboardStyle.css">
    <link rel="stylesheet" href="../design/sidebarStyle.css">
</head>
<body class="admin-page">

    <!-- SIDEBAR -->
    <?php include("sidebar.php"); ?>

    <!-- MAIN CONTENT -->
    <main class="main-content">

        <section class="section-content">
            <h1>Welcome, <?= htmlspecialchars($adminName) ?></h1>

            <div class="stats-cards">
                <div class="card total-reservations">
                    <h3>Total Reservations</h3>
                    <p id="totalReservations">0</p>
                </div>

                <div class="card pending-reservations">
                    <h3>Pending Reservations</h3>
                    <p id="pendingReservations">0</p>
                </div>

                <div class="card confirmed-reservations">
                    <h3>Confirmed Reservations</h3>
                    <p id="confirmedReservations">0</p>
                </div>
            </div>
        </section>

    </main>

    <script src="admin.js"></script>
</body>
</html>