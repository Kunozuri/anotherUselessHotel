<?php
include("dbInclude.php");

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // --- FETCH ADMIN BY USERNAME
    $admin = $db->fetchWhere('admins', ['username' => $username]);

    if (count($admin) === 1) {
        $adminData = $admin[0];

        // --- CHECK IF ACCOUNT IS ACTIVE
        if ($adminData['is_active'] == 0) {
            $error = "This account is disabled.";
        } else {
            // --- VERIFY PASSWORD
            if (password_verify($password, $adminData['password_hash']))
            {
                // --- PASSWORD MATCHED
                $_SESSION['adminLoggedIn'] = true;
                $_SESSION['admin_id'] = $adminData['admin_id'];
                $_SESSION['adminName'] = $adminData['username'];

                // --- UPDATE LAST LOGIN
                $db->updateWhere(
                    'admins',
                    ['last_login' => date('Y-m-d H:i:s')],
                    ['admin_id' => $adminData['admin_id']]
                );

                // --- REDIRECT TO DASHBOARD
                header("Location: dashboard.php");
                exit;
            }
            
            else
            {
                $error = "Invalid username or password.";
            }
        }
    }
    
    else
    {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../design/loginStyle.css">
</head>
<body>
    <div class="login-container">
        <h2>Admin Login</h2>

        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form action="" method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Enter username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter password" required>

            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>