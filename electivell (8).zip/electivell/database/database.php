<?php


// ---
class Database
{
    // -------------------------------------------------------------------------------------
    //  DATABASE CONSTRUCTOR AND DECONSTRUCTOR
    // -------------------------------------------------------------------------------------

    // --- DATABASE CONSTRUCTOR FOR INITIAL SET UP
    public function __construct(string $host, string $user, string $password, string $dbName)
    {
        // --- CREATE THE DATABASE FRST IF ITS NOT EXISTING
        $this->createDB($host, $user, $password, $dbName);

        // --- CONNECT TO THE DATABASE
        $this->connect($host, $user, $password, $dbName);

        // --- INITIALIZE TABLES, INSURING ALL THE TABLES ARE CREATED
        $this->initializeTables();

        // --- CREATE SUPER USER
        $this->insertAdmin("Gelrik", "GelPogie");
    }

    // --- DATABASE DECONSTRUCTOR FOR CLOSING THE CONNECTION OF DATABASE
    public function __destruct()
    {
        $this->disconnect();
    }


    // -------------------------------------------------------------------------------------
    // PRIVATE VARS THAT THE DATABASE NEEDS
    // -------------------------------------------------------------------------------------
    private mysqli $conn; // --- SQL CONNECTOR OBJECT


    // -------------------------------------------------------------------------------------
    // PRIVATE FUNCTION FOR INITIAL SET UP OF THE DATABASE 
    // -------------------------------------------------------------------------------------

    // --- PRIVATE METHOD TO CREATE DATABASE IF IT DOES NOT YET EXIST
    private function createDB($host, $user, $password, $dbName)
    {
        //--- CONNECT WITHOUT SELECTING THE DATABASE
        // --- THIS ALLOWES TO RUN SERVER LEVEL COMMAD, (IN SHORT CONNECT TO THE SERVER)
        $conn = new mysqli($host, $user, $password);

        // --- CHECKPOINT : KILL IF CONNECTION TO THE SERVER IS INVALID
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // --- DATABASE QUERIES
        $sql = "CREATE DATABASE IF NOT EXISTS `$dbName`
            CHARACTER SET utf8mb4
            COLLATE utf8mb4_unicode_ci";

        // --- CHECKPOINT : KILL IF THE QUERY FAILS TO EXECUTE
        if (!$conn->query($sql)) {
            die("Error creating database: " . $conn->error);
        }

        // --- CLOSE THE CONNECTION TO SERVER
        $conn->close();
    }

    // --- FUNCTION TO CONNECT TO THE DATABASE
    private function connect($host, $user, $password, $dbName)
    {
        $this->conn = new mysqli($host, $user, $password, $dbName);
        if ($this->conn->connect_error) {
            die("DB connection failed: " . $this->conn->connect_error);
        }

        $this->conn->set_charset("utf8mb4");
    }

    // --- FUNCTION TO DISCONNECT TO THE DATABASE
    private function disconnect()
    {
        if (isset($this->conn)) {
            $this->conn->close();
        }
    }

    // --- FUNCTION TO RUN THE QUERY OF YOUR DATABASE
    private function query(string $sql)
    {
        return $this->conn->query($sql);
    }


    // -------------------------------------------------------------------------------------
    // PRIVATE FUNCTION USED TO TEMPORARILY CREATE A SUPER USER
    // -------------------------------------------------------------------------------------

    // --- GENERIC FUNCTION TO INSERT AN ADMIN ACCOUNT IF NOT EXISTS
    private function insertAdmin(string $username, string $password, bool $isActive = true)
    {
        // --- CHECK IF ADMIN USERNAME ALREADY EXISTS
        $existing = $this->fetchWhere('admins', ['username' => $username]);
        if (!empty($existing)) {
            // --- USERNAME EXISTS, DO NOT INSERT
            return false;
        }

        // --- ESCAPE USERNAME
        $username = $this->conn->real_escape_string($username);

        // --- HASH PASSWORD SECURELY
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // --- CONVERT BOOLEAN TO INT
        $isActiveInt = $isActive ? 1 : 0;

        // --- BUILD SQL
        $sql = "
            INSERT INTO `admins` (`username`, `password_hash`, `is_active`)
            VALUES ('$username', '$passwordHash', $isActiveInt)
        ";

        // --- EXECUTE QUERY
        if (!$this->query($sql)) {
            die("Error inserting admin: " . $this->conn->error);
        }

        // --- RETURN THE NEW ADMIN ID
        return $this->conn->insert_id;
    }


    // -------------------------------------------------------------------------------------
    // PRIVATE FUNCTION USED TO RUN QUERRIES FOR CREATING TABLES 
    // -------------------------------------------------------------------------------------

    // --- PRIVATE FUNCTION TO CREATE THE ROOMS TABLE
    private function createRoomsTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS `rooms` (
                `room_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `room_type` ENUM('Standard', 'Deluxe', 'Family Suite') NOT NULL,
                `price_per_night` DECIMAL(10,2) NOT NULL,
                `capacity` INT UNSIGNED NOT NULL,
                `description` TEXT,
                `status` ENUM('Available', 'Booked', 'Maintenance') NOT NULL DEFAULT 'Available',
                `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`room_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating rooms table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO CREATE THE ROOM IMAGES TABLE
    private function createRoomImagesTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS `room_images` (
                `image_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `room_id` INT UNSIGNED NOT NULL,
                `image_path` VARCHAR(255) NOT NULL,
                `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`image_id`),
                FOREIGN KEY (`room_id`) REFERENCES `rooms`(`room_id`)
                    ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating room_images table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO CREATE THE AMENITIES TABLE
    private function createAmenitiesTable()
    {
        $sql = "
        CREATE TABLE IF NOT EXISTS `amenities` (
            `amenity_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `amenity_name` VARCHAR(100) NOT NULL,
            `description` TEXT,
            `price` DECIMAL(10,2) DEFAULT 0.00,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (`amenity_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating amenities table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO CREATE THE AMENITY IMAGES TABLE
    private function createAmenityImagesTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS `amenity_images` (
                `image_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `amenity_id` INT UNSIGNED NOT NULL,
                `image_path` VARCHAR(255) NOT NULL,
                `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`image_id`),
                FOREIGN KEY (`amenity_id`) REFERENCES `amenities`(`amenity_id`)
                    ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating amenity_images table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO CREATE THE ROOM-AMENITY RELATION TABLE
    private function createRoomAmenitiesTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS `room_amenities` (
                `room_amenity_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `room_id` INT UNSIGNED NOT NULL,
                `amenity_id` INT UNSIGNED NOT NULL,
                `included` TINYINT(1) NOT NULL DEFAULT 0,
                PRIMARY KEY (`room_amenity_id`),
                FOREIGN KEY (`room_id`) REFERENCES `rooms`(`room_id`) ON DELETE CASCADE ON UPDATE CASCADE,
                FOREIGN KEY (`amenity_id`) REFERENCES `amenities`(`amenity_id`) ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating room_amenities table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO CREATE THE RESERVATIONS TABLE
    private function createReservationsTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS `reservations` (
                `reservation_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `first_name` VARCHAR(50) NOT NULL,
                `middle_name` VARCHAR(50),
                `last_name` VARCHAR(50) NOT NULL,
                `date_of_birth` DATE,
                `age` INT UNSIGNED,
                `address` VARCHAR(255) NOT NULL,
                `zip_code` VARCHAR(20),
                `city_or_region` VARCHAR(100) NOT NULL,
                `contact_number` VARCHAR(20) NOT NULL,
                `email` VARCHAR(100) NOT NULL,
                `room_id` INT UNSIGNED NOT NULL,
                `check_in_date` DATE NOT NULL,
                `check_out_date` DATE NOT NULL,
                `number_of_guests` INT UNSIGNED NOT NULL,
                `nights` INT UNSIGNED,
                `reservation_status` ENUM('Pending', 'Approved', 'Rejected', 'Cancelled') NOT NULL DEFAULT 'Pending',
                `reservation_reference` VARCHAR(50) NOT NULL UNIQUE,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`reservation_id`),
                FOREIGN KEY (`room_id`) REFERENCES `rooms`(`room_id`) ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating reservations table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO CREATE THE RESERVATION AMENITIES TABLE
    private function createReservationAmenitiesTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS `reservation_amenities` (
                `reservation_amenity_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `reservation_id` INT UNSIGNED NOT NULL,
                `amenity_id` INT UNSIGNED NOT NULL,
                `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
                `price_at_booking` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                PRIMARY KEY (`reservation_amenity_id`),
                FOREIGN KEY (`reservation_id`) REFERENCES `reservations`(`reservation_id`) ON DELETE CASCADE ON UPDATE CASCADE,
                FOREIGN KEY (`amenity_id`) REFERENCES `amenities`(`amenity_id`) ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating reservation_amenities table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO CREATE THE PAYMENTS TABLE
    private function createPaymentsTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS `payments` (
                `payment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `reservation_id` INT UNSIGNED NOT NULL,
                `price_per_night` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                `amenities_cost` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                `total_cost` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                `payment_status` ENUM('Pending', 'Completed', 'Failed', 'Refunded') NOT NULL DEFAULT 'Pending',
                `computed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`payment_id`),
                FOREIGN KEY (`reservation_id`) REFERENCES `reservations`(`reservation_id`) ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating payments table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO CREATE THE ADMINS TABLE
    private function createAdminsTable()
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS `admins` (
                `admin_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `username` VARCHAR(50) NOT NULL UNIQUE,
                `password_hash` VARCHAR(255) NOT NULL,
                `last_login` DATETIME DEFAULT NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`admin_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ";

        if (!$this->query($sql)) {
            die("Error creating admins table: " . $this->conn->error);
        }
    }

    // --- PRIVATE FUNCTION TO INITIALIZE ALL TABLES
    private function initializeTables()
    {
        $this->createRoomsTable();
        $this->createAmenitiesTable();

        $this->createRoomImagesTable();
        $this->createAmenityImagesTable();

        $this->createRoomAmenitiesTable();
        $this->createReservationsTable();
        $this->createReservationAmenitiesTable();
        $this->createPaymentsTable();

        $this->createAdminsTable();
    }


    // -------------------------------------------------------------------------------------
    // PUBLIC FUNCTION FOR CRUD OPERATION
    // -------------------------------------------------------------------------------------

    // --- GENERIC FETCH FUNCTION
    public function fetchWhere(string $table, array $conditions = [], string $operator = "AND")
    {
        // --- SELECT EVERYTHING FROM THE TABLE IF THERES NO CONDITION IS PASSED
        $sql = "SELECT * FROM `$table`";

        // --- IF THERES A CONDITION SELECTED THEN APPEND AN STRING TO THE QUERY
        if (!empty($conditions)) {
            $clauses = [];

            // --- FROM THE CONDITION SEPARETED BY => LEFT IS COLOMN, RIGHT IS VALUE TO SEARCH
            foreach ($conditions as $column => $value) {
                // --- ERROR HANDLIN : ENSURE THE QUERRY IS SAVE TO PUT AS VALUE
                $value = $this->conn->real_escape_string($value);

                // --- ARRANGE THE SEARCH VALUE
                $clauses[] = "`$column` LIKE '%$value%'";
            }

            // --- ARRANGE QUERY
            $sql .= " WHERE " . implode(" $operator ", $clauses);
        }

        // --- QUERRY THIS THEN DIE IF THERES AN ERROR OTEHRWISE SAFELY RETURN
        $result = $this->query($sql);
        if (!$result) {
            die("Fetch error: " . $this->conn->error);
        }

        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // --- GENERIC UPDATE FUNCTION
    public function updateWhere(string $table, array $data, array $conditions, string $operator = "AND")
    {
        // --- VALIDATE INPUTS
        if (empty($data) || empty($conditions)) {
            return false; // NOTHING TO UPDATE OR NO CONDITIONS
        }

        // --- ESCAPE AND BUILD SET CLAUSE
        $setClauses = [];
        foreach ($data as $column => $value) {
            $value = $this->conn->real_escape_string($value);
            $setClauses[] = "`$column` = '$value'";
        }
        $setString = implode(", ", $setClauses);

        // --- ESCAPE AND BUILD WHERE CLAUSE
        $whereClauses = [];
        foreach ($conditions as $column => $value) {
            $value = $this->conn->real_escape_string($value);
            $whereClauses[] = "`$column` = '$value'";
        }
        $whereString = implode(" $operator ", $whereClauses);

        // --- BUILD AND EXECUTE QUERY
        $sql = "UPDATE `$table` SET $setString WHERE $whereString";

        $result = $this->query($sql);
        if (!$result) {
            die("Update error: " . $this->conn->error);
        }

        // --- RETURN NUMBER OF ROWS UPDATED
        return $this->conn->affected_rows;
    }

    // --- GENERIC DELETE FUNCTION
    public function deleteWhere(string $table, array $conditions, string $operator = "AND")
    {
        // --- SAFETY CHECK: NEVER DELETE WITHOUT CONDITIONS
        if (empty($conditions)) {
            return false;
        }

        // --- ESCAPE AND BUILD WHERE CLAUSE
        $whereClauses = [];
        foreach ($conditions as $column => $value) {
            $value = $this->conn->real_escape_string($value);
            $whereClauses[] = "`$column` = '$value'";
        }
        $whereString = implode(" $operator ", $whereClauses);

        // --- BUILD AND EXECUTE QUERY
        $sql = "DELETE FROM `$table` WHERE $whereString";

        $result = $this->query($sql);
        if (!$result) {
            die("Delete error: " . $this->conn->error);
        }

        // --- RETURN NUMBER OF ROWS DELETED
        return $this->conn->affected_rows;
    }

    // --- GENERIC INSERT FUNCTION
    public function insert(string $table, array $data)
    {
        if (empty($data)) {
            return false;
        }

        $columns = [];
        $values  = [];

        foreach ($data as $column => $value) {
            $columns[] = "`$column`";
            $values[]  = "'" . $this->conn->real_escape_string($value) . "'";
        }

        $columnsString = implode(", ", $columns);
        $valuesString  = implode(", ", $values);

        $sql = "INSERT INTO `$table` ($columnsString) VALUES ($valuesString)";

        $result = $this->query($sql);
        if (!$result) {
            die("Insert error: " . $this->conn->error);
        }

        // --- RETURN INSERTED ID
        return $this->conn->insert_id;
    }


    // -------------------------------------------------------------------------------------
    // PUBLIC FUNCTION FOR JOINT OPERATION
    // -------------------------------------------------------------------------------------

    // --- GENERIC JOIN/FETCH FUNCTION
    public function fetchJoin(string $baseTable, array $joins = [], array $conditions = [], string $operator = "AND", string $orderBy = "")
    {
        // --- Parse base table and alias
        $parts = explode(' ', $baseTable, 2);
        $tableName = $parts[0];
        $alias = $parts[1] ?? '';

        $sql = "SELECT $tableName.*";
        if ($alias) {
            $sql = "SELECT $alias.*"; // use alias for select
        }

        // --- Add join select columns
        $joinSelects = [];
        foreach ($joins as $join) {
            if (!empty($join['select'])) {
                foreach ($join['select'] as $aliasCol => $column) {
                    $joinSelects[] = "$column AS $aliasCol";
                }
            }
        }
        if (!empty($joinSelects)) {
            $sql .= ", " . implode(", ", $joinSelects);
        }

        // --- FROM clause
        $sql .= " FROM `$tableName`";
        if ($alias) {
            $sql .= " $alias";
        }

        // --- JOIN clauses
        foreach ($joins as $join) {
            $type = strtoupper($join['type'] ?? 'INNER');
            $parts = explode(' ', $join['table'], 2);
            $joinTable = $parts[0];
            $joinAlias = $parts[1] ?? '';
            $on = $join['on'];

            $sql .= " $type JOIN `$joinTable`";
            if ($joinAlias) {
                $sql .= " $joinAlias";
            }
            $sql .= " ON $on";
        }

        // --- WHERE conditions
        if (!empty($conditions)) {
            $clauses = [];
            foreach ($conditions as $column => $value) {
                $value = $this->conn->real_escape_string($value);
                if (strtoupper($value) === "NULL") {
                    $clauses[] = "$column IS NULL";
                } else {
                    $value = $this->conn->real_escape_string($value);
                    $clauses[] = "$column = '$value'";
                }
            }
            $sql .= " WHERE " . implode(" $operator ", $clauses);
        }

        // --- ORDER BY
        if ($orderBy) {
            $sql .= " ORDER BY $orderBy";
        }

        // --- Execute
        $result = $this->query($sql);
        if (!$result) {
            die("FetchJoin error: " . $this->conn->error);
        }

        return $result->fetch_all(MYSQLI_ASSOC);
    }


    // -------------------------------------------------------------------------------------
    // PUBLIC FUNCTION FOR 
    // -------------------------------------------------------------------------------------

    // --- GENERIC FUNCTION TO GET DEFAULT FORM VALUES FROM TABLE
    public function getDefaultFormValues(string $table, array $customDefaults = []): array
    {
        $sql = "SHOW COLUMNS FROM `$table`";
        $result = $this->query($sql);

        if (!$result) {
            die("Error fetching columns from $table: " . $this->conn->error);
        }

        $formValues = [];
        while ($row = $result->fetch_assoc()) {
            $field = $row['Field'];
            $type = strtoupper($row['Type']);
            $extra = strtoupper($row['Extra']);

            // Skip auto-increment or datetime/timestamp columns
            if (strpos($extra, 'AUTO_INCREMENT') !== false || strpos($type, 'DATETIME') !== false || strpos($type, 'TIMESTAMP') !== false) {
                continue;
            }

            // Use custom default if provided
            if (isset($customDefaults[$field])) {
                $formValues[$field] = $customDefaults[$field];
            } else {
                $formValues[$field] = '';
            }
        }

        return $formValues;
    }
}
