<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- INCLUDE THE DATABSE CLASS
require_once "../../database/database.php";

// --- CREATE DATABASE OBJECT
$db = new Database("localhost", "root", "", "hotel_db");
?>