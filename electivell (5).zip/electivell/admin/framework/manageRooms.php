<?php
// --- INCLUDE ADMIN DATABASE (kept for session & sidebar)
include("dbInclude.php");

// --- AUTH PROTECTION (REQUIRED)
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- HANDLE DELETEs
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_room_id'])) {
    $roomId = (int) $_POST['delete_room_id'];

    $db->deleteWhere('rooms', ['room_id' => $roomId]);

    // --- PREVENT RESUBMISSION ON REFRESH
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// --- ADMIN NAME
$adminName = $_SESSION['adminName'] ?? "Admin";

// --- FECTH ALL THE AVAILABLE ROOMS PLUS ITS IMAGES
$rooms = $db->fetchJoin(
    'rooms r',
    [
        [
            'type' => 'LEFT',
            'table' => 'room_images ri',
            'on' => 'r.room_id = ri.room_id AND ri.is_primary = 1',
            'select' => ['image' => 'ri.image_path']
        ]
    ],
    [],
    'AND',
    'r.room_id DESC'
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Rooms</title>
    <link rel="stylesheet" href="../design/sidebarStyle.css">
    <link rel="stylesheet" href="../design/manageRoomsStyle.css">
</head>
<body class="admin-page">

    <!-- SIDEBAR -->
    <?php include("sidebar.php"); ?>

    <!-- MAIN CONTENT -->
    <main class="main-content">

        <section class="section-content">
            <h1>Manage Rooms</h1>

            <a href="addEditRoom.php" class="action-btn">
                Add New Room
            </a>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Price / Night</th>
                        <th>Capacity</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>

                    <?php if (!empty($rooms)): ?>
                        <?php foreach ($rooms as $room): ?>
                            <tr>
                                <td><?= $room['room_id'] ?></td>
                                <td><?= htmlspecialchars($room['room_type']) ?></td>
                                <td><?= number_format($room['price_per_night'], 2) ?></td>
                                <td><?= $room['capacity'] ?></td>
                                <td><?= $room['status'] ?></td>
                                <td>
                                    <?php if (!empty($room['image'])): ?>
                                        <img src="../../assets/rooms/<?= htmlspecialchars(basename($room['image'])) ?>" alt="Room Image" style="width:100px; border-radius:6px;">
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="addEditRoom.php?id=<?= $room['room_id'] ?>" class="action-btn edit-btn">Edit</a>

                                    <form method="POST"
                                        style="display:inline;"
                                        onsubmit="return confirm('Are you sure you want to delete this room?');">

                                        <input type="hidden" name="delete_room_id" value="<?= $room['room_id'] ?>">
                                        <button type="submit" class="action-btn delete-btn">Delete</button>

                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align:center;">No rooms found.</td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>

        </section>

    </main>
</body>
</html>