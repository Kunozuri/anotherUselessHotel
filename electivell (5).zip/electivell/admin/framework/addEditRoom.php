<?php
include("dbInclude.php");

// --- AUTH PROTECTION
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- CHECK MODE
$isEdit = isset($_GET['id']);
$roomId = $isEdit ? (int) $_GET['id'] : null;

// --- DEFAULT FORM VALUES
$room = $db->getDefaultFormValues('rooms');

// --- FETCH ROOM IF EDIT MODE
if ($isEdit) {
    $result = $db->fetchWhere('rooms', ['room_id' => $roomId]);
    if (!$result) {
        header("Location: manageRooms.php");
        exit;
    }
    $room = $result[0];

    // --- Fetch existing images
    $images = $db->fetchWhere('room_images', ['room_id' => $roomId]);
} else {
    $images = [];
}

// --- HANDLE IMAGE DELETE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_image_id'])) {
    $imageId = (int) $_POST['delete_image_id'];
    $imgData = $db->fetchWhere('room_images', ['image_id' => $imageId]);
    if ($imgData) {
        $filePath   = __DIR__ . "/../../" . $imgData[0]['image_path'];
        if (file_exists($filePath)) unlink($filePath);
        $db->deleteWhere('room_images', ['image_id' => $imageId]);
    }
    header("Location: addEditRoom.php?id=$roomId");
    exit;
}

// --- HANDLE FORM SUBMIT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['delete_image_id'])) {

    // --- COLLECT FORM DATA
    $data = [
        'room_type' => $_POST['room_type'],
        'price_per_night' => $_POST['price_per_night'],
        'capacity' => $_POST['capacity'],
        'description' => $_POST['description'] ?? '',
        'status' => $_POST['status'],
        'is_featured' => isset($_POST['is_featured']) ? 1 : 0
    ];

    if ($isEdit) {
        $db->updateWhere('rooms', $data, ['room_id' => $roomId]);
    } else {
        $roomId = $db->insert('rooms', $data);
    }

    // Update primary image for existing images (only if editing)
    if ($isEdit && isset($_POST['primary_image_index'])) {
        foreach ($images as $i => $img) {
            $db->updateWhere('room_images', ['is_primary' => ($i == $_POST['primary_image_index'] ? 1 : 0)], ['image_id' => $img['image_id']]);
        }
    }

    // --- HANDLE MULTIPLE IMAGE UPLOAD
    $targetDir = __DIR__ . "/../assets/rooms/";
    if (!is_dir($targetDir)) mkdir($targetDir, 0755, true);

    $primaryIndex = $_POST['primary_image_index'] ?? null;

    // Fetch current images for this room
    $currentImages = $db->fetchWhere('room_images', ['room_id' => $roomId]);
    $hasPrimary = false;
    foreach ($currentImages as $img) {
        if ($img['is_primary']) {
            $hasPrimary = true;
            break;
        }
    }

    foreach ($_FILES['room_images']['name'] as $index => $fileName) {
        if (!empty($fileName)) {
            $tmpName = $_FILES['room_images']['tmp_name'][$index];
            $fileNameNew = time() . "_" . uniqid() . "_" . basename($fileName);
            $targetPath = $targetDir . $fileNameNew;

            if (move_uploaded_file($tmpName, $targetPath)) {
                // Determine if this should be primary
                $isPrimary = 0;
                if (!$hasPrimary) {
                    $isPrimary = 1;
                    $hasPrimary = true; // now a primary exists
                } elseif ($primaryIndex !== null && $primaryIndex == $index) {
                    $isPrimary = 1;
                    // Reset previous primary
                    $db->updateWhere('room_images', ['is_primary' => 0], ['room_id' => $roomId]);
                }

                $db->insert('room_images', [
                    'room_id' => $roomId,
                    'image_path' => '/assets/rooms/' . $fileNameNew,
                    'is_primary' => $isPrimary
                ]);
            }
        }
    }

    header("Location: manageRooms.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $isEdit ? 'Edit Room' : 'Add Room' ?></title>
    <link rel="stylesheet" href="../design/dashboardStyle.css">
    <link rel="stylesheet" href="../design/sidebarStyle.css">
    <style>
        .room-image { display:inline-block; margin:10px; position:relative; }
        .room-image img { width:100px; border-radius:6px; }
        .delete-btn { background-color:#e74c3c;color:white;border:none;padding:2px 6px;cursor:pointer;margin-top:5px; }
    </style>
</head>
<body class="admin-page">

<?php include("sidebar.php"); ?>

<main class="main-content">
<section class="section-content">

<h1><?= $isEdit ? 'Edit Room' : 'Add New Room' ?></h1>

<form method="POST" enctype="multipart/form-data">

    <label>Room Type</label>
    <input type="text" name="room_type" required value="<?= htmlspecialchars($room['room_type']) ?>">

    <label>Price Per Night</label>
    <input type="number" name="price_per_night" required value="<?= $room['price_per_night'] ?>">

    <label>Capacity</label>
    <input type="number" name="capacity" required value="<?= $room['capacity'] ?>">

    <label>Status</label>
    <select name="status">
        <?php
        $statuses = ['Available', 'Booked', 'Maintenance'];
        foreach ($statuses as $status):
        ?>
            <option value="<?= $status ?>" <?= $room['status'] === $status ? 'selected' : '' ?>>
                <?= $status ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Description</label>
    <textarea name="description"><?= htmlspecialchars($room['description']) ?></textarea>

    <label>
        <input type="checkbox" name="is_featured" <?= $room['is_featured'] ? 'checked' : '' ?>>
        Featured Room
    </label>

    <label>Upload Room Images</label>
    <input type="file" name="room_images[]" accept="image/*" multiple>

    <?php if ($isEdit && !empty($images)): ?>
        <h4>Existing Images</h4>
        <?php foreach ($images as $i => $img): ?>
            <div class="room-image">
                <img src="../../assets/rooms/<?= htmlspecialchars(basename($img['image_path'])) ?>" alt="Room Image">

                <!-- Delete button outside main form -->
                <a href="addEditRoom.php?id=<?= $roomId ?>&delete_image_id=<?= $img['image_id'] ?>" 
                onclick="return confirm('Remove this image?')" class="delete-btn">Remove</a>

                <label style="display:block;margin-top:5px;">
                    <input type="radio" name="primary_image_index" value="<?= $i ?>" <?= $img['is_primary'] ? 'checked' : '' ?>>
                    Primary
                </label>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <br><br>
    <button type="submit" class="action-btn"
        style="background-color:<?= $isEdit ? '#3498db' : '#2ecc71' ?>;color:white;">
        <?= $isEdit ? 'Save Changes' : 'Add Room' ?>
    </button>
    <a href="manageRooms.php" class="action-btn">Cancel</a>

</form>

</section>
</main>
</body>
</html>