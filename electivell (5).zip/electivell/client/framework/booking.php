<?php 
include("header.php");

// -----------------------------
// GET ROOM + AMENITIES FROM SESSION
// -----------------------------
$roomType = $_SESSION['roomType'] ?? ($_POST['room_type'] ?? 'Deluxe');
$extraAmenities = $_SESSION['addedAmenity'] ?? ($_POST['amenities'] ?? []);

$_SESSION['roomType'] = $roomType;
$_SESSION['addedAmenity'] = $extraAmenities;

$freeAmenities = ['Free Wi-Fi'];

// -----------------------------
// HANDLE FORM SUBMISSION
// -----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['full_name'])) {

    $guestName    = $_POST['full_name'];
    $guestEmail   = $_POST['email'];
    $guestPhone   = $_POST['phone'];
    $guestDOB     = $_POST['dob'];
    $guestAge     = $_POST['age'];
    $guestAddress = $_POST['address'];
    $guestCount   = (int)$_POST['guests'];
    $payment      = $_POST['payment'] ?? null;

    // Basic age validation (server-side)
    if ($guestAge < 18) {
        $error = "Guest must be at least 18 years old.";
    } else {

        /*
        // DATABASE INSERT COMMENT (FOR BACKEND TEAM)

        $sql = "INSERT INTO bookings 
                (room_type, guests, fullname, email, phone, dob, age, address, payment_method, amenities)
                VALUES (:room_type, :guests, :fullname, :email, :phone, :dob, :age, :address, :payment, :amenities)";
        */

        $_SESSION['guestInfo'] = [
            'name' => $guestName,
            'email' => $guestEmail,
            'phone' => $guestPhone,
            'dob' => $guestDOB,
            'age' => $guestAge,
            'address' => $guestAddress,
            'guests' => $guestCount,
            'payment' => $payment
        ];

        header("Location: payment.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Your Stay</title>
    <link rel="stylesheet" href="../design/bookingStyle.css">
</head>
<body>

<section class="reserve-hero">
    <h1>Book Your Stay</h1>
    <p>Complete your reservation details below.</p>
</section>

<section class="reserve-container">

<form id="reservationForm" method="POST">

<div class="reserve-card">

<h2>Guest Information</h2>

<?php if(isset($error)): ?>
    <p style="color:red;"><?= $error ?></p>
<?php endif; ?>

<div class="form-group">
    <label>Full Name</label>
    <input type="text" name="full_name" required>
</div>

<div class="form-group">
    <label>Email Address</label>
    <input type="email" name="email" required>
</div>

<div class="form-group">
    <label>Phone Number</label>
    <input type="text" name="phone" required>
</div>

<div class="form-row">
    <div class="form-group">
        <label>Date of Birth</label>
        <input type="date" id="dob" name="dob" required>
    </div>

    <div class="form-group small">
        <label>Age</label>
        <input type="text" id="age" name="age" readonly>
    </div>
</div>

<div class="form-group">
    <label>Address</label>
    <textarea name="address" required></textarea>
</div>

<div class="form-group">
    <label>Number of Guests</label>
    <input type="number" name="guests" min="1" max="10" value="2" required>
</div>

<h2>Booking Details</h2>

<p><strong>Room Selected:</strong> <?= htmlspecialchars($roomType) ?></p>

<hr>

<p><strong>Included Amenities:</strong></p>
<ul>
<?php foreach ($freeAmenities as $amenity): ?>
    <li><?= htmlspecialchars($amenity) ?></li>
<?php endforeach; ?>
</ul>

<?php if (!empty($extraAmenities)): ?>
<hr>
<p><strong>Additional Amenities:</strong></p>
<ul>
<?php foreach ($extraAmenities as $amenity): ?>
    <li><?= htmlspecialchars($amenity) ?></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<h2>Payment Method</h2>

<div class="radio-group">
    <label><input type="radio" name="payment" value="Cash" required> Cash</label>
    <label><input type="radio" name="payment" value="Credit Card"> Credit Card</label>
    <label><input type="radio" name="payment" value="GCash"> GCash</label>
</div>

<!-- PASS DATA FOR PAYMENT PAGE -->
<input type="hidden" name="room_type" value="<?= htmlspecialchars($roomType) ?>">
<?php foreach ($extraAmenities as $amenity): ?>
    <input type="hidden" name="amenities[]" value="<?= htmlspecialchars($amenity) ?>">
<?php endforeach; ?>

<button class="confirm-btn" type="submit">
    Proceed to Payment
</button>

</div>
</form>

</section>

<!-- JAVASCRIPT -->
<script>
const dobInput = document.getElementById("dob");
const ageInput = document.getElementById("age");
const form = document.getElementById("reservationForm");

dobInput.addEventListener("change", function () {
    const dob = new Date(dobInput.value);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
        age--;
    }

    ageInput.value = age;
});

form.addEventListener("submit", function (e) {
    if (ageInput.value === "" || ageInput.value < 18) {
        e.preventDefault();
        alert("Guest must be at least 18 years old.");
    }
});
</script>

</body>
</html>

<?php include("footer.html"); ?>