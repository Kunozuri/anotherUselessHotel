<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Prevent undefined session
if (!isset($_SESSION['roomNumber'])) {
    header("Location: room.php");
    exit;
}

$roomNumber = (int)$_SESSION['roomNumber'];

// -----------------------------
// AMENITY MAP
// -----------------------------
$amenityMap = [
    1 => 'Mini Bar',
    2 => 'Extra Bed',
    3 => 'Sea View',
    4 => 'Room Service',
    5 => 'Breakfast Included'
];

// -----------------------------
// DEFAULT ROOM DATA
// -----------------------------
$roomData = [
    'title' => "Room $roomNumber",
    'description' => "A comfortable room with modern amenities, perfect for relaxation.",
    'price' => 150,
    'images' => [],
    'free_amenity' => ['Wi-Fi', 'Air Conditioning', 'Flat-screen TV', 'Bathroom essentials'],
    'additional_amenity' => ['Mini Bar', 'Extra Bed', 'Sea View', 'Room Service']
];

// -----------------------------
// LOAD ROOM IMAGES DYNAMICALLY
// -----------------------------
$roomImagePath = "../../assets/rooms/$roomNumber/";

if (is_dir($roomImagePath)) {
    $files = scandir($roomImagePath);

    foreach ($files as $file) {
        if ($file !== "." && $file !== "..") {
            $roomData['images'][] = $roomImagePath . $file;
        }
    }

    // Sort images naturally (1.jpg, 2.jpg, 10.jpg correctly ordered)
    natsort($roomData['images']);
}

// If no images exist, add placeholder
if (empty($roomData['images'])) {
    $roomData['images'][] = "../../assets/rooms/default.jpg";
}

// -----------------------------
// ADD AMENITY IF SELECTED
// -----------------------------
if (isset($_SESSION['amenityNumber']) && isset($amenityMap[$_SESSION['amenityNumber']])) {

    $selectedAmenity = $amenityMap[$_SESSION['amenityNumber']];

    if (!in_array($selectedAmenity, $roomData['additional_amenity'])) {
        $roomData['additional_amenity'][] = $selectedAmenity;
    }
}

// -----------------------------
// BUTTON HANDLERS
// -----------------------------
if (isset($_POST['add-amenity'])) {
    $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];
    header("Location: amenity.php");
    exit;
}

if (isset($_POST['book-now'])) {
    $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];
    $_SESSION['addedAmenity'] = $_POST['amenities'] ?? [];
    header("Location: booking.php");
    exit;
}

// -----------------------------
// HEADER
// -----------------------------
include("header.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($roomData['title']) ?> Details</title>
    <link rel="stylesheet" href="../design/roomDetailStyle.css">
</head>

<body>

<h1><?= htmlspecialchars($roomData['title']) ?></h1>

<!-- ROOM IMAGES -->
<div class="room-images">
    <?php foreach ($roomData['images'] as $img): ?>
        <img src="<?= htmlspecialchars($img) ?>" alt="Room Image">
    <?php endforeach; ?>
</div>

<!-- ROOM DETAILS -->
<div class="room-details">

    <h2>Description</h2>
    <p><?= htmlspecialchars($roomData['description']) ?></p>

    <h2>Price</h2>
    <p>$<?= number_format($roomData['price'], 2) ?> per night</p>

    <h2>Free Amenities</h2>
    <ul>
        <?php foreach ($roomData['free_amenity'] as $amenity): ?>
            <li><?= htmlspecialchars($amenity) ?></li>
        <?php endforeach; ?>
    </ul>

    <h2>Additional Amenities</h2>
    <ul>
        <?php foreach ($roomData['additional_amenity'] as $amenity): ?>
            <li><?= htmlspecialchars($amenity) ?></li>
        <?php endforeach; ?>
    </ul>

    <div class="buttons">

        <form method="POST" style="display:inline;">
            <input type="hidden" name="roomNumber" value="<?= $roomNumber ?>">
            <button type="submit" name="add-amenity" class="add-amenity">
                Add Amenity
            </button>
        </form>

        <form method="POST" style="display:inline;">
            <input type="hidden" name="roomNumber" value="<?= $roomNumber ?>">

            <?php foreach ($roomData['additional_amenity'] as $amenity): ?>
                <input type="hidden" name="amenities[]" value="<?= htmlspecialchars($amenity) ?>">
            <?php endforeach; ?>

            <button type="submit" name="book-now" class="btn-book">
                Book Now
            </button>
        </form>

    </div>
</div>

</body>
</html>

<?php include("footer.html"); ?>
