<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$roomNumber = $_SESSION['roomNumber'];
$amenityNumber = $_SESSION['amenityNumber'];

//--- MAP OF ALL AVAILABLE AMENITIES (DEFAULT DATA)
$amenityMap = [
        1 => [
            'title' => 'Mini Bar',
            'description' => 'Enjoy refreshments conveniently inside your room.',
            'price' => 25,
            'images' => [
                "../../assets/amenities/1/1.jpg",
                "../../assets/amenities/1/2.jpg",
                "../../assets/amenities/1/3.jpg"
            ]
        ],
        2 => [
            'title' => 'Extra Bed',
            'description' => 'Perfect for additional guests staying overnight.',
            'price' => 40,
            'images' => [
                "../../assets/amenities/2/1.jpg",
                "../../assets/amenities/2/2.jpg",
                "../../assets/amenities/2/3.jpg"
            ]
        ],
        3 => [
            'title' => 'Sea View',
            'description' => 'Enjoy a beautiful ocean view from your room.',
            'price' => 60,
            'images' => [
                "../../assets/amenities/3/1.jpg",
                "../../assets/amenities/3/2.jpg",
                "../../assets/amenities/3/3.jpg"
            ]
        ],
        4 => [
            'title' => 'Room Service',
            'description' => 'Order food and services directly to your room.',
            'price' => 30,
            'images' => [
                "../../assets/amenities/4/1.jpg",
                "../../assets/amenities/4/2.jpg",
                "../../assets/amenities/4/3.jpg"
            ]
        ],
        5 => [
            'title' => 'Breakfast Included',
            'description' => 'Daily breakfast included with your stay.',
            'price' => 20,
            'images' => [
                "../../assets/amenities/5/1.jpg",
                "../../assets/amenities/5/2.jpg",
                "../../assets/amenities/5/3.jpg"
            ]
        ]
];

//--- SELECT CURRENT AMENITY
$amenityData = $amenityMap[$amenityNumber] ?? $amenityMap[1];

//--- WHEN ADD AMENITY IS CLICKED, REDIRECT BACK TO ROOM DETAILS
if (isset($_POST['add-amenity']) && isset($_SESSION['roomNumber'])) {
    $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];
    $_SESSION['amenityNumber'] = (int)$_POST['amenityNumber'];
    header("Location: roomDetails.php?");
    exit;
}

//--- HEADER OF THE HOME PAGE
include("header.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $amenityData['title'] ?> Details</title>
    <link rel="stylesheet" href="../design/amenityDetailStyle.css">
</head>

<body>
    <h1><?= $amenityData['title'] ?></h1>

    <!-- AMENITY IMAGES -->
    <div class="amenity-images">
        <?php foreach ($amenityData['images'] as $img): ?>
            <img src="<?= $img ?>" alt="Amenity Image">
        <?php endforeach; ?>
    </div>

    <!-- AMENITY DETAILS -->
    <div class="amenity-details">
        <h2>Description</h2>
        <p><?= $amenityData['description'] ?></p>

        <h2>Price</h2>
        <p>$<?= number_format($amenityData['price'], 2) ?></p>

        <div class="buttons">
            <?php if (isset($_SESSION['roomNumber'])): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="roomNumber" value="<?= $_SESSION['roomNumber'] ?>">
                    <button type="submit" name="add-amenity" class="add-amenity"> Add Amenity </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>

<!-- FOOTER OF THE HOME PAGE -->
<?php include("footer.html"); ?>