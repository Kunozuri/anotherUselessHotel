<?php include("header.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel La Maria - Home</title>
    <link rel="stylesheet" href="../design/homeStyle.css">
</head>

<body>
    <!-- HERO SECTION -->
    <section class="hero-section">
        <div class="hero-content">
            <h1>Welcome to Hotel La Maria</h1>
            <p>Experience comfort, elegance, and premium amenities for an unforgettable stay.</p>
            <a href="room.php" class="btn-primary">Explore Rooms</a>
        </div>
    </section>

    <!-- ROOMS PREVIEW -->
    <section class="preview-section">
        <div class="section-header">
            <h2>Featured Rooms</h2>
            <p>Take a glimpse of our most popular rooms. Click to see full details.</p>
        </div>

        <div class="preview-cards">
            <?php
                // FETCH FEATURED ROOMS FROM DATABASE
                $featuredRooms = $db->fetchWhere('rooms', ['is_featured' => 1]);

                // LOOP THROUGH EACH FEATURED ROOM
                foreach ($featuredRooms as $roomData)
                {
                    // ESCAPE VALUES FOR SAFETY
                    $roomId = htmlspecialchars($roomData['room_id']);
                    $roomType = htmlspecialchars($roomData['room_type']);
                    $roomDesc = htmlspecialchars($roomData['description']);

                    // FETCH ALL IMAGES FOR THIS ROOM
                    $roomImages = $db->fetchWhere('room_images', ['room_id' => $roomData['room_id']]);

                    // FIND PRIMARY IMAGE
                    $primaryImage = null;
                    foreach ($roomImages as $img)
                    {
                        if ($img['is_primary']) {
                            $primaryImage = htmlspecialchars($img['image_path']);
                            break;
                        }
                    }

                    echo '<div class="card">';
                    
                    // DISPLAY IMAGE ONLY IF PRIMARY EXISTS
                    if ($primaryImage)
                    {
                        echo '<img src="../../assets/rooms/'.$roomId.'/'.$primaryImage.'" alt="'.$roomType.' Room">';
                    }

                    echo '
                        <h3>'.$roomType.'</h3>
                        <p>'.$roomDesc.'</p>
                        <a href="roomDetails.php?room='.$roomId.'" class="btn-secondary">View Details</a>
                    </div>';
                }
            ?>
        </div>

        <div class="section-footer">
            <a href="room.php" class="btn-primary">View All Rooms</a>
        </div>
    </section>

    <!-- AMENITIES PREVIEW -->
    <section class="preview-section">
        <div class="section-header">
            <h2>Our Amenities</h2>
            <p>Discover premium features designed to enhance your comfort and elevate your stay.</p>
        </div>

        <div class="preview-cards">
            <?php
                // --- FETCH FEATURED AMENITIES FROM DATABASE
                $featuredAmenities = $db->fetchWhere('amenities', ['is_featured' => 1]);

                // --- LOOP THROUGH EACH FEATURED AMENITY
                foreach ($featuredAmenities as $amenityData) {

                    // --- ESCAPE VALUES FOR SAFETY
                    $amenityId = htmlspecialchars($amenityData['amenity_id']);
                    $amenityName = htmlspecialchars($amenityData['amenity_name']);
                    $amenityDesc = htmlspecialchars($amenityData['description']);

                    // --- FETCH ALL IMAGES FOR THIS AMENITY
                    $amenityImages = $db->fetchWhere('amenity_images', ['amenity_id' => $amenityData['amenity_id']]);

                    // --- FIND PRIMARY IMAGE
                    $primaryImage = null;
                    foreach ($amenityImages as $img) {
                        if ($img['is_primary']) {
                            $primaryImage = htmlspecialchars($img['image_path']);
                            break;
                        }
                    }

                    echo '<div class="card">';

                    // --- DISPLAY IMAGE ONLY IF PRIMARY EXISTS
                    if ($primaryImage) {
                        echo '<img src="../../assets/amenities/'.$amenityId.'/'.$primaryImage.'" alt="'.$amenityName.'">';
                    }

                    echo '
                        <h3>'.$amenityName.'</h3>
                        <p>'.$amenityDesc.'</p>
                        <a href="amenityDetails.php?amenity='.$amenityId.'" class="btn-secondary">View Details</a>
                    </div>';
                }
            ?>
        </div>

        <div class="section-footer">
            <a href="amenity.php" class="btn-primary">View All Amenities</a>
        </div>
    </section>
</body>
</html>

<?php include("footer.html"); ?>
