<?php include("header.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Amenities</title>
    <link rel="stylesheet" href="../design/amenityStyle.css">
</head>

<body>

<section class="amenity-section">

    <div class="amenity-header">
        <h1>Our Amenities</h1>
        <p>Discover premium features designed to enhance your comfort and elevate your stay experience.</p>
    </div>

    <div class="amenity-scroll">

    <?php
    // -----------------------------
    // 5 UNIQUE AMENITIES
    // -----------------------------
    $amenities = $db->fetchWhere("amenities"); 

    // -----------------------------
    // HANDLE VIEW DETAILS CLICK
    // -----------------------------
    if (isset($_POST['view-details'])) {
        $_SESSION['amenityNumber'] = (int)$_POST['amenityNumber'];
        if (isset($_POST['roomNumber'])) {
            $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];
        }
        header("Location: amenityDetails.php");
        exit;
    }

    // -----------------------------
    // RENDER AMENITY CARDS
    // -----------------------------
    foreach ($amenities as $amenityNumber => $amenityData) {
        renderAmenityCard($amenityNumber, $amenityData, $db);
    }

    ?>
    </div>
</section>

</body>
</html>

<?php include("footer.html"); ?>

<?php
function renderAmenityCard(int $amenityNumber, array $amenityData, Database $db) {

    // FETCH ALL IMAGES FOR THIS AMENITY
    $amenityImages = $db->fetchWhere('amenity_images', ['amenity_id' => $amenityData['amenity_id']]);

    // SORT IMAGES SO PRIMARY IMAGE COMES FIRST
    usort($amenityImages, function($a, $b) {
        return $b['is_primary'] <=> $a['is_primary'];
    });
?>
<div class="amenity-card">

    <!-- AMENITY IMAGES -->
    <div class="amenity-images">
        <?php foreach ($amenityImages as $img): ?>
            <img src="../../assets/amenities/<?= $amenityData['amenity_id'] ?>/<?= htmlspecialchars($img['image_path']) ?>" 
                 alt="<?= htmlspecialchars($amenityData['amenity_name']) ?> IMAGE">
        <?php endforeach; ?>
    </div>

    <!-- LABEL -->
    <h4>AMENITY <?= $amenityNumber ?></h4>

    <!-- AMENITY NAME -->
    <h3><?= htmlspecialchars($amenityData['amenity_name']) ?></h3>

    <!-- AMENITY DESCRIPTION -->
    <p class="amenity-desc"><?= htmlspecialchars($amenityData['description']) ?></p>

    <!-- AMENITY TYPE AND PRICE -->
    <p class="amenity-price">
        <?= htmlspecialchars($amenityData['amenity_type']) ?> - $<?= number_format($amenityData['price'], 2) ?>
    </p>

    <!-- DETAILS BUTTON -->
    <form method="POST">
        <input type="hidden" name="amenityNumber" value="<?= $amenityNumber ?>">
        <?php if(isset($_SESSION['roomNumber'])): ?>
            <input type="hidden" name="roomNumber" value="<?= $_SESSION['roomNumber'] ?>">
        <?php endif; ?>
        <button type="submit" name="view-details" class="room-btn">VIEW DETAILS</button>
    </form>

</div>
<?php
}
?>
