<?php 
include("header.php"); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Rooms</title>
    <link rel="stylesheet" href="../design/roomStyle.css">
</head>

<body>

<div class="room-scroll">
    
    <div class="room-header">
        <h1>Our Rooms</h1>
        <p>Explore rooms that'll fit your needs and interest be it as solo or a whole circle.</p>
    </div>
<?php

// --- GET ALL THE ROOMS IN THE DATABASE
$rooms = $db->fetchWhere("rooms");

// -----------------------------
// HANDLE VIEW DETAILS CLICK
// -----------------------------
if (isset($_POST['view-details'])) {
    $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];
    unset($_SESSION['amenityNumber']);
    header("Location: roomDetails.php");
    exit;
}

// -----------------------------
// RENDER ROOM CARDS
// -----------------------------
foreach ($rooms as $roomNumber => $roomData) {
    renderRoomCard($roomNumber, $roomData, $db);
}

?>
</div>

</body>
</html>

<?php include("footer.html"); ?>

<?php
function renderRoomCard(int $roomNumber, array $roomData, Database $db)
{ 
    // --- FETCH ALL IMAGES FOR THIS ROOM
    $roomImages = $db->fetchWhere('room_images', ['room_id' => $roomData['room_id']]);

    // --- SORT IMAGES SO PRIMARY IMAGE COMES FIRST
    usort($roomImages, function($a, $b) {
        return $b['is_primary'] <=> $a['is_primary'];
    });
?>
    <div class="room-card">

        <!-- ROOM IMAGES -->
        <div class="room-images">
            <?php foreach ($roomImages as $img): ?>
                <img src="../../assets/rooms/<?= $roomData['room_id'] ?>/<?= htmlspecialchars($img['image_path']) ?>" 
                     alt="ROOM IMAGE">
            <?php endforeach; ?>
        </div>

        <!-- ROOM TYPE -->
        <h3><?= htmlspecialchars($roomData['room_type']) ?></h3>

        <!-- ROOM DESCRIPTION -->
        <p class="room-desc">
            <?= htmlspecialchars($roomData['description']) ?>
        </p>

        <!-- ROOM CAPACITY -->
        <p class="room-capacity">
            CAPACITY: <?= htmlspecialchars($roomData['capacity']) ?> GUESTS
        </p>

        <!-- ROOM PRICE -->
        <p class="room-price">
            $<?= number_format($roomData['price_per_night'], 2) ?> PER NIGHT
        </p>

        <!-- ROOM STATUS -->
        <p class="room-status">
            STATUS: <?= htmlspecialchars($roomData['status']) ?>
        </p>

        <!-- DETAILS BUTTON -->
        <form method="post">
            <input type="hidden" name="roomNumber" value="<?= $roomNumber ?>">
            <button type="submit" name="view-details" class="room-btn">
                VIEW DETAILS
            </button>
        </form>

    </div>
<?php
}
?>
