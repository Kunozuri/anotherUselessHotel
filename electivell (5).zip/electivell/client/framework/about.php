<?php include("header.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | Hotel La Maria</title>
    <link rel="stylesheet" href="../design/aboutStyle.css">
</head>

<body>

<!-- Hero Section -->
<section class="about-hero">
    <h1>About the Creators</h1>
    <p>Meet the team behind Hotel La Maria Booking System</p>
</section>

<!-- ID Cards Grid -->
<section class="id-grid">

<?php
$members = [
    [
        "id" => "001",
        "name" => "Marc Rammyr Busa",
        "role" => "Frontend Developer",
        "specialty" => "HTML, CSS, JavaScript",
        "image" => "../../assets/creators/1.jpg"
    ],
    [
        "id" => "002",
        "name" => "Gelrik Globio",
        "role" => "Backend Developer",
        "specialty" => "PHP & MySQL",
        "image" => "../../assets/creators/2.jpg"
    ],
    [
        "id" => "003",
        "name" => "Guilven Osila",
        "role" => "Database Designer",
        "specialty" => "ERD & MySQL",
        "image" => "../../assets/creators/3.jpg"
    ]
];

foreach ($members as $member) {
    echo '
    <div class="id-card">
        <div class="id-header">
            Hotel La Maria • Creator ID <span>#'.$member["id"].'</span>
        </div>
        <div class="id-body">
            <div class="photo">
                <img src="'.$member["image"].'" alt="Member Photo">
            </div>
            <div class="id-info">
                <h3>'.$member["name"].'</h3>
                <p>Role: '.$member["role"].'</p>
                <p>Specialty: '.$member["specialty"].'</p>
                <p>Student: Computer Science</p>
                <span class="badge">Active Member</span>
            </div>
        </div>
        <div class="id-footer">
            <span>Issued: 2026</span>
            <span>Hotel La Maria</span>
        </div>
        <div class="watermark">HotelLaMaria</div>
    </div>
    ';
}
?>

</section>

</body>
</html>

<?php include("footer.html"); ?>
