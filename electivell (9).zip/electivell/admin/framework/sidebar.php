<?php
// --- LOGOUT HANDLER
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

// --- AUTH PROTECTION
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- GET CURRENT PAGE
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<!-- SIDE BAR NAVIGATION FOR ADMIN -->
<aside class="sidebar">
    <div class="sidebar-header">
        <h2>Admin Panel</h2>
        <p>Hotel La Maria</p>
    </div>

    <nav class="sidebar-nav">
        <a href="dashboard.php" class="<?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
            <span>🏠</span> Dashboard
        </a>

        <a href="reservationHistory.php" class="<?= $currentPage === 'reservationHistory.php' ? 'active' : '' ?>">
            <span>📜</span> Reservation History
        </a>

        <a href="scheduledReservations.php" class="<?= $currentPage === 'scheduledReservations.php' ? 'active' : '' ?>">
            <span>⏰</span> Scheduled Reservations
        </a>

        <a href="manageRooms.php" class="<?= $currentPage === 'manageRooms.php' ? 'active' : '' ?>">
            <span>🛏️</span> Manage Rooms
        </a>

        <a href="manageAmenities.php" class="<?= $currentPage === 'manageAmenities.php' ? 'active' : '' ?>">
            <span>🧴</span> Manage Amenities
        </a>

        <a href="?logout=true" class="logout">
            <span>🚪</span> Logout
        </a>
    </nav>
</aside>