<?php
// --- INCLUDE DATABASE CONNECTION
include("dbInclude.php");

// --- AUTHENTICATION PROTECTION | REDIRECT IF NOT LOGGED IN
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- DETERMINE IF EDIT MODE OR ADD MODE
$isEdit = isset($_GET['id']);
$roomId = $isEdit ? (int) $_GET['id'] : null;

// --- FETCH ALL ACTIVE AMENITIES FROM DATABASE
$amenities = $db->fetchWhere('amenities', ['is_active' => 1]);

// --- FETCH ROOM AMENITIES IF EDIT MODE
$roomAmenities = [];
if ($isEdit) {
    $rows = $db->fetchWhere('room_amenities', ['room_id' => $roomId]);
    foreach ($rows as $ra) {
        $roomAmenities[$ra['amenity_id']] = $ra['included'];
    }
}

// --- GET DEFAULT ROOM VALUES FROM DATABASE
$room = $db->getDefaultFormValues('rooms');

// --- INITIALIZE ROOM IMAGES ARRAY
$images = [];

// --- FETCH ROOM DETAILS AND IMAGES IF EDIT MODE
if ($isEdit) {
    // --- FETCH ROOM DATA BY ID
    $result = $db->fetchWhere('rooms', ['room_id' => $roomId]);
    if (!$result) {
        header("Location: manageRooms.php");
        exit;
    }

    // --- SET ROOM DATA
    $room = $result[0];

    // --- FETCH IMAGES ASSOCIATED WITH THIS ROOM
    $images = $db->fetchWhere('room_images', ['room_id' => $roomId]);
}

// --- HANDLE FORM SUBMISSION (SAVE OR DELETE IMAGE)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- DETERMINE ACTION CLICKED
    $action = $_POST['action'] ?? '';

    // --- DELETE IMAGE ACTION
    if ($action === 'delete_image') {
        // --- GET IMAGE ID TO DELETE
        $imageId = (int) $_POST['delete_image_id'];
        $imgData = $db->fetchWhere('room_images', ['image_id' => $imageId]);

        // --- DELETE IMAGE FILE AND DATABASE RECORD
        if ($imgData) {
            $filePath = __DIR__ . "/../" . $imgData[0]['image_path'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            $db->deleteWhere('room_images', ['image_id' => $imageId]);
        }

        // --- REFRESH PAGE AFTER DELETE
        header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $roomId);
        exit;
    }

    // --- SAVE ROOM DATA ACTION
    if ($action === 'save') {
        // --- COLLECT FORM DATA
        $data = [
            'room_type' => $_POST['room_type'],
            'price_per_night' => $_POST['price_per_night'],
            'capacity' => $_POST['capacity'],
            'description' => $_POST['description'] ?? '',
            'status' => $_POST['status'],
            'is_featured' => isset($_POST['is_featured']) ? 1 : 0
        ];

        // --- INSERT OR UPDATE ROOM DATA
        if ($isEdit) {
            $db->updateWhere('rooms', $data, ['room_id' => $roomId]);
        } else {
            $roomId = $db->insert('rooms', $data);
            $isEdit = true;
        }

        // --- HANDLE PRIMARY IMAGE SELECTION
        if (isset($_POST['primary_image_id'])) {
            $db->updateWhere('room_images', ['is_primary' => 0], ['room_id' => $roomId]);
            $db->updateWhere('room_images', ['is_primary' => 1], ['image_id' => (int)$_POST['primary_image_id']]);
        }

        // --- ENSURE ROOM IMAGE FOLDER EXISTS
        $targetDir = __DIR__ . "/../assets/rooms/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        // --- GET CURRENT ROOM IMAGES
        $currentImages = $db->fetchWhere('room_images', ['room_id' => $roomId]);
        $hasPrimary = false;
        foreach ($currentImages as $img) {
            if ($img['is_primary']) {
                $hasPrimary = true; // --- PRIMARY IMAGE EXISTS
                break;
            }
        }

        // --- HANDLE IMAGE UPLOADS
        if (!empty($_FILES['room_images']['name'][0])) {
            foreach ($_FILES['room_images']['name'] as $index => $fileName) {
                if (empty($fileName)) continue; // --- SKIP EMPTY FILES

                $tmpName = $_FILES['room_images']['tmp_name'][$index];
                $newFileName = time() . "_" . uniqid() . "_" . basename($fileName);
                $targetPath = $targetDir . $newFileName;

                if (move_uploaded_file($tmpName, $targetPath)) {
                    $isPrimaryNew = $hasPrimary ? 0 : 1;
                    if (!$hasPrimary) $hasPrimary = true;

                    $db->insert('room_images', [
                        'room_id' => $roomId,
                        'image_path' => '/assets/rooms/' . $newFileName,
                        'is_primary' => $isPrimaryNew
                    ]);
                }
            }
        }

        // --- HANDLE ROOM AMENITIES
        $selectedAmenities = $_POST['amenities'] ?? [];
        $db->deleteWhere('room_amenities', ['room_id' => $roomId]);
        foreach ($selectedAmenities as $amenityId) {
            $db->insert('room_amenities', [
                'room_id' => $roomId,
                'amenity_id' => (int)$amenityId,
                'included' => 1
            ]);
        }

        // --- REDIRECT TO ROOM MANAGEMENT
        header("Location: manageRooms.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- PAGE META DATA -->
    <meta charset="UTF-8">
    <title><?= $isEdit ? 'Edit Room' : 'Add Room' ?></title>
    <link rel="stylesheet" href="../design/dashboardStyle.css">
    <link rel="stylesheet" href="../design/sidebarStyle.css">
    <style>
        /* --- ROOM IMAGE STYLE */
        .room-image {
            display: inline-block;
            margin: 10px;
        }

        .room-image img {
            width: 100px;
            border-radius: 6px;
            display: block;
        }

        /* --- DELETE BUTTON STYLE */
        .delete-btn {
            background: #e74c3c;
            color: #fff;
            border: none;
            padding: 4px 8px;
            cursor: pointer;
            margin-top: 5px;
        }
    </style>
</head>

<body class="admin-page">

    <!-- INCLUDE SIDEBAR -->
    <?php include("sidebar.php"); ?>

    <main class="main-content">
        <section class="section-content">

            <!-- PAGE TITLE -->
            <h1><?= $isEdit ? 'Edit Room' : 'Add New Room' ?></h1>

            <!-- ROOM FORM START -->
            <form method="POST" enctype="multipart/form-data">

                <input type="hidden" name="action" value="save">

                <!-- ROOM TYPE SELECT -->
                <label>Room Type</label>
                <select name="room_type" required>
                    <option value="">-- Select Room Type --</option>
                    <?php
                    $roomTypes = ['Standard', 'Deluxe', 'Family Suite'];
                    foreach ($roomTypes as $type):
                    ?>
                        <option value="<?= $type ?>" <?= $room['room_type'] === $type ? 'selected' : '' ?>>
                            <?= $type ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- PRICE PER NIGHT INPUT -->
                <label>Price Per Night</label>
                <input type="number" name="price_per_night" required value="<?= $room['price_per_night'] ?>">

                <!-- CAPACITY INPUT -->
                <label>Capacity</label>
                <input type="number" name="capacity" required value="<?= $room['capacity'] ?>">

                <!-- ROOM STATUS SELECT -->
                <label>Status</label>
                <select name="status">
                    <?php
                    $statuses = ['Available', 'Booked', 'Maintenance'];
                    foreach ($statuses as $status):
                    ?>
                        <option value="<?= $status ?>" <?= $room['status'] === $status ? 'selected' : '' ?>>
                            <?= $status ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <br><br>

                <!-- ROOM DESCRIPTION -->
                <label>Description</label>
                <textarea name="description"><?= htmlspecialchars($room['description']) ?></textarea>

                <br><br>

                <!-- FEATURED ROOM CHECKBOX -->
                <label>
                    <input type="checkbox" name="is_featured" <?= $room['is_featured'] ? 'checked' : '' ?>>
                    Featured Room
                </label>

                <br><br>

                <!-- UPLOAD ROOM IMAGES -->
                <label>Upload Room Images</label>
                <input type="file" name="room_images[]" multiple>

                <!-- EXISTING IMAGES DISPLAY -->
                <?php if ($isEdit && !empty($images)): ?>
                    <h4>Existing Images</h4>
                    <?php foreach ($images as $img): ?>
                        <div class="room-image">

                            <!-- IMAGE DISPLAY -->
                            <img src="../assets/rooms/<?= htmlspecialchars(basename($img['image_path'])) ?>">

                            <!-- PRIMARY IMAGE RADIO -->
                            <label>
                                <input type="radio" name="primary_image_id" value="<?= $img['image_id'] ?>" <?= $img['is_primary'] ? 'checked' : '' ?>>
                                Primary
                            </label>

                            <!-- REMOVE IMAGE BUTTON -->
                            <button type="submit" name="action" value="delete_image" class="delete-btn" onclick="return confirm('Delete this image?')">
                                Remove
                            </button>

                            <!-- HIDDEN IMAGE ID FOR DELETE -->
                            <input type="hidden" name="delete_image_id" value="<?= $img['image_id'] ?>">

                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

                <br><br>

                <!-- ROOM AMENITIES CHECKBOXES -->
                <label>Room Amenities Included</label>
                <div class="amenities-list">
                    <?php foreach ($amenities as $amenity): ?>
                        <label style="display:block;margin-bottom:6px;">
                            <input type="checkbox" name="amenities[]" value="<?= $amenity['amenity_id'] ?>" <?= isset($roomAmenities[$amenity['amenity_id']]) && $roomAmenities[$amenity['amenity_id']] ? 'checked' : '' ?>>
                            <?= htmlspecialchars($amenity['amenity_name']) ?>
                        </label>
                    <?php endforeach; ?>
                </div>

                <br><br>

                <!-- SAVE OR ADD ROOM BUTTON -->
                <button type="submit" class="action-btn" style="background-color:<?= $isEdit ? '#3498db' : '#2ecc71' ?>;color:white;">
                    <?= $isEdit ? 'Save Changes' : 'Add Room' ?>
                </button>

                <!-- CANCEL BUTTON -->
                <a href="manageRooms.php" class="action-btn">Cancel</a>

            </form>
            <!-- ROOM FORM END -->

        </section>
    </main>
</body>

</html>