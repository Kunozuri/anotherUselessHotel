<?php
// --- INCLUDE ADMIN DATABASE
include("dbInclude.php");

// --- AUTH PROTECTION
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- GET TODAY'S DATE
$today = date('Y-m-d');

// --- FETCH PAST RESERVATIONS (check_out_date < today)
$pastReservations = $db->fetchWhere(
    'reservations',
    ['check_out_date' => $today], 
    '<' // custom operator, so we'll handle in code
);

// --- CUSTOM HANDLING FOR OPERATOR '<'
if (!empty($pastReservations)) {
    // Filter manually because fetchWhere only supports LIKE/=
    $pastReservations = array_filter($pastReservations, function($r) use ($today) {
        return $r['check_out_date'] < $today;
    });
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservation History</title>
    <link rel="stylesheet" href="../design/reservationHistoryStyle.css">
    <link rel="stylesheet" href="../design/sidebarStyle.css">
</head>
<body class="admin-page">

    <!-- SIDEBAR -->
    <?php include("sidebar.php"); ?>

    <!-- MAIN CONTENT -->
    <main class="main-content">
        <section class="section-content">
            <h1>Reservation History</h1>

            <?php if (!empty($pastReservations)): ?>
                <table class="reservation-history">
                    <thead>
                        <tr>
                            <th>Reference</th>
                            <th>Guest Name</th>
                            <th>Room ID</th>
                            <th>Check-In</th>
                            <th>Check-Out</th>
                            <th>Guests</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pastReservations as $res): ?>
                            <tr>
                                <td><?= htmlspecialchars($res['reservation_reference']) ?></td>
                                <td>
                                    <?= htmlspecialchars($res['first_name'] . ' ' . ($res['middle_name'] ?? '') . ' ' . $res['last_name']) ?>
                                </td>
                                <td><?= htmlspecialchars($res['room_id']) ?></td>
                                <td><?= htmlspecialchars($res['check_in_date']) ?></td>
                                <td><?= htmlspecialchars($res['check_out_date']) ?></td>
                                <td><?= htmlspecialchars($res['number_of_guests']) ?></td>
                                <td><?= htmlspecialchars($res['reservation_status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No past reservations found.</p>
            <?php endif; ?>
        </section>
    </main>

</body>
</html>