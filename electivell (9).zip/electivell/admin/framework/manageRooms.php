<?php
// --- INCLUDE ADMIN DATABASE (USED FOR SESSION & SIDEBAR)
include("dbInclude.php");

// --- AUTHENTICATION PROTECTION (REDIRECT IF NOT LOGGED IN)
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- HANDLE DELETE ROOM IF FORM SUBMITTED
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_room_id'])) {

    // --- GET ROOM ID TO DELETE
    $roomId = (int) $_POST['delete_room_id'];

    // --- FETCH ALL IMAGES RELATED TO THIS ROOM
    $roomImages = $db->fetchWhere('room_images', ['room_id' => $roomId]);

    if ($roomImages) {
        foreach ($roomImages as $image) {

            // --- DELETE IMAGE FILE FROM STORAGE
            $filePath = __DIR__ . "/../" . $image['image_path'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }

        // --- DELETE IMAGE RECORDS FROM DATABASE
        $db->deleteWhere('room_images', ['room_id' => $roomId]);
    }

    // --- DELETE ROOM RECORD FROM DATABASE
    $db->deleteWhere('rooms', ['room_id' => $roomId]);

    // --- REDIRECT TO PREVENT FORM RESUBMISSION
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// --- GET ADMIN NAME FROM SESSION
$adminName = $_SESSION['adminName'] ?? "Admin";

// --- FETCH ALL ROOMS WITH LEFT JOIN ON PRIMARY IMAGE
$rooms = $db->fetchJoin(
    'rooms r',
    [
        [
            'type' => 'LEFT',
            'table' => 'room_images ri',
            'on' => 'r.room_id = ri.room_id AND ri.is_primary = 1',
            'select' => ['image' => 'ri.image_path']
        ]
    ],
    [],
    'AND',
    'r.room_id DESC'
);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- PAGE META DATA -->
    <meta charset="UTF-8">
    <title>Manage Rooms</title>

    <!-- STYLESHEETS -->
    <link rel="stylesheet" href="../design/sidebarStyle.css">
    <link rel="stylesheet" href="../design/manageRoomsStyle.css">
</head>

<body class="admin-page">

    <!-- SIDEBAR INCLUDE -->
    <?php include("sidebar.php"); ?>

    <!-- MAIN CONTENT -->
    <main class="main-content">

        <section class="section-content">

            <!-- PAGE TITLE -->
            <h1>Manage Rooms</h1>

            <!-- ADD NEW ROOM BUTTON -->
            <a href="addEditRoom.php" class="action-btn">
                Add New Room
            </a>

            <!-- ROOMS TABLE -->
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Price / Night</th>
                        <th>Capacity</th>
                        <th>Status</th>
                        <th>Featured</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>

                    <!-- CHECK IF ROOMS EXIST -->
                    <?php if (!empty($rooms)): ?>
                        <?php foreach ($rooms as $room): ?>
                            <tr>
                                <!-- ROOM ID -->
                                <td><?= $room['room_id'] ?></td>

                                <!-- ROOM TYPE -->
                                <td><?= htmlspecialchars($room['room_type']) ?></td>

                                <!-- ROOM PRICE PER NIGHT -->
                                <td><?= number_format($room['price_per_night'], 2) ?></td>

                                <!-- ROOM CAPACITY -->
                                <td><?= $room['capacity'] ?></td>

                                <!-- ROOM STATUS -->
                                <td><?= $room['status'] ?></td>

                                <!-- ROOM FEATURED STATUS -->
                                <td><?= $room['is_featured'] == 1 ? 'Yes' : 'No' ?></td>

                                <!-- ROOM PRIMARY IMAGE -->
                                <td>
                                    <?php if (!empty($room['image'])): ?>
                                        <img src="../assets/rooms/<?= htmlspecialchars(basename($room['image'])) ?>" alt="Room Image">
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>

                                <!-- ACTIONS BUTTONS: EDIT & DELETE -->
                                <td>
                                    <!-- EDIT BUTTON -->
                                    <a href="addEditRoom.php?id=<?= $room['room_id'] ?>" class="action-btn edit-btn">
                                        Edit
                                    </a>

                                    <!-- DELETE FORM BUTTON -->
                                    <form method="POST"
                                        style="display:inline;"
                                        onsubmit="return confirm('Are you sure you want to delete this room?');">

                                        <!-- HIDDEN ROOM ID FOR DELETE -->
                                        <input type="hidden" name="delete_room_id" value="<?= $room['room_id'] ?>">

                                        <!-- DELETE BUTTON -->
                                        <button type="submit" class="action-btn delete-btn">Delete</button>

                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- NO ROOMS FOUND -->
                        <tr>
                            <td colspan="8">No rooms found.</td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>

        </section>

    </main>
</body>

</html>