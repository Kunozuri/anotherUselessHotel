<?php
// --- INCLUDE DATABASE CONNECTION
include("dbInclude.php");

// --- AUTH PROTECTION (ADMIN ONLY)
if (!isset($_SESSION['adminLoggedIn'])) {
    header("Location: login.php");
    exit;
}

// --- CHECK MODE (EDIT OR ADD)
$isEdit = isset($_GET['id']);
$amenityId = $isEdit ? (int) $_GET['id'] : null;

// --- GET DEFAULT FORM VALUES FROM AMENITIES TABLE
$amenity = $db->getDefaultFormValues('amenities');

// --- INITIALIZE LIST OF IMAGES
$images = [];

// --- FETCH EXISTING AMENITY DATA IF EDIT MODE
if ($isEdit) {
    // --- FETCH AMENITY BY ID
    $result = $db->fetchWhere('amenities', ['amenity_id' => $amenityId]);
    if (!$result) {
        header("Location: manageAmenities.php");
        exit;
    }

    // --- GET FIRST RESULT
    $amenity = $result[0];

    // --- FETCH IMAGES ASSOCIATED WITH THIS AMENITY
    $images = $db->fetchWhere('amenity_images', ['amenity_id' => $amenityId]);
}

// --- HANDLE FORM SUBMISSION
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- DETERMINE ACTION FROM FORM
    $action = $_POST['action'] ?? '';

    // --- DELETE IMAGE ACTION
    if ($action === 'delete_image') {

        // --- GET IMAGE ID TO DELETE
        $imageId = (int) $_POST['delete_image_id'];
        $imgData = $db->fetchWhere('amenity_images', ['image_id' => $imageId]);

        if ($imgData) {
            // --- DELETE IMAGE FILE FROM SERVER
            $filePath = __DIR__ . "/../" . $imgData[0]['image_path'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }

            // --- DELETE IMAGE RECORD FROM DATABASE
            $db->deleteWhere('amenity_images', ['image_id' => $imageId]);
        }

        // --- REFRESH PAGE
        header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $amenityId);
        exit;
    }

    // --- SAVE AMENITY DATA ACTION
    if ($action === 'save') {

        // --- COLLECT FORM DATA
        $data = [
            'amenity_name' => $_POST['amenity_name'],
            'description' => $_POST['description'] ?? '',
            'price' => $_POST['price'],
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
            'is_featured' => isset($_POST['is_featured']) ? 1 : 0
        ];

        // --- UPDATE OR INSERT AMENITY RECORD
        if ($isEdit) {
            $db->updateWhere('amenities', $data, ['amenity_id' => $amenityId]);
        } else {
            $amenityId = $db->insert('amenities', $data);
            $isEdit = true;
        }

        // --- HANDLE PRIMARY IMAGE SELECTION
        if (isset($_POST['primary_image_id'])) {
            // --- UNSET PREVIOUS PRIMARY
            $db->updateWhere('amenity_images', ['is_primary' => 0], ['amenity_id' => $amenityId]);
            // --- SET NEW PRIMARY IMAGE
            $db->updateWhere('amenity_images', ['is_primary' => 1], ['image_id' => (int)$_POST['primary_image_id']]);
        }

        // --- ENSURE IMAGE STORAGE FOLDER EXISTS
        $targetDir = __DIR__ . "/../assets/amenities/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        // --- FETCH CURRENT IMAGES FOR AMENITY
        $currentImages = $db->fetchWhere('amenity_images', ['amenity_id' => $amenityId]);
        $hasPrimary = false;
        foreach ($currentImages as $img) {
            if ($img['is_primary']) {
                $hasPrimary = true;
                break;
            }
        }

        // --- PROCESS UPLOADED IMAGES
        if (!empty($_FILES['amenity_images']['name'][0])) {
            foreach ($_FILES['amenity_images']['name'] as $index => $fileName) {
                if (empty($fileName)) continue;

                $tmpName = $_FILES['amenity_images']['tmp_name'][$index];
                $newFileName = time() . "_" . uniqid() . "_" . basename($fileName);
                $targetPath = $targetDir . $newFileName;

                if (move_uploaded_file($tmpName, $targetPath)) {
                    $isPrimaryNew = $hasPrimary ? 0 : 1;
                    if (!$hasPrimary) $hasPrimary = true;

                    $db->insert('amenity_images', [
                        'amenity_id' => $amenityId,
                        'image_path' => '/assets/amenities/' . $newFileName,
                        'is_primary' => $isPrimaryNew
                    ]);
                }
            }
        }

        // --- REDIRECT BACK TO AMENITY MANAGEMENT
        header("Location: manageAmenities.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- --- PAGE META CHARSET -->
    <meta charset="UTF-8">
    <!-- --- PAGE TITLE -->
    <title><?= $isEdit ? 'Edit Amenity' : 'Add Amenity' ?></title>
    <!-- --- LINK STYLESHEETS -->
    <link rel="stylesheet" href="../design/dashboardStyle.css">
    <link rel="stylesheet" href="../design/sidebarStyle.css">

    <!-- --- INLINE STYLES FOR IMAGE THUMBNAILS -->
    <style>
        .room-image {
            display: inline-block;
            margin: 10px;
        }

        .room-image img {
            width: 100px;
            border-radius: 6px;
            display: block;
        }

        .delete-btn {
            background: #e74c3c;
            color: #fff;
            border: none;
            padding: 4px 8px;
            cursor: pointer;
            margin-top: 5px;
        }
    </style>
</head>

<body class="admin-page">

    <!-- --- INCLUDE SIDEBAR -->
    <?php include("sidebar.php"); ?>

    <!-- --- MAIN CONTENT AREA -->
    <main class="main-content">
        <section class="section-content">

            <!-- --- PAGE HEADING -->
            <h1><?= $isEdit ? 'Edit Amenity' : 'Add New Amenity' ?></h1>

            <!-- --- AMENITY FORM -->
            <form method="POST" enctype="multipart/form-data">

                <input type="hidden" name="action" value="save">

                <!-- --- AMENITY NAME INPUT -->
                <label>Amenity Name</label>
                <input type="text" name="amenity_name" required value="<?= htmlspecialchars($amenity['amenity_name']) ?>">

                <!-- --- AMENITY PRICE INPUT -->
                <label>Price</label>
                <input type="number" step="0.01" name="price" value="<?= $amenity['price'] ?>">

                <!-- --- AMENITY DESCRIPTION -->
                <label>Description</label>
                <textarea name="description"><?= htmlspecialchars($amenity['description']) ?></textarea>

                <!-- --- ACTIVE CHECKBOX -->
                <label>
                    <input type="checkbox" name="is_active" <?= $amenity['is_active'] ? 'checked' : '' ?>>
                    Active
                </label>

                <!-- --- FEATURED CHECKBOX -->
                <label>
                    <input type="checkbox" name="is_featured" <?= $amenity['is_featured'] ? 'checked' : '' ?>>
                    Featured Amenity
                </label>

                <!-- --- UPLOAD NEW IMAGES -->
                <label>Upload Amenity Images</label>
                <input type="file" name="amenity_images[]" multiple>

                <!-- --- EXISTING IMAGES DISPLAY (EDIT MODE ONLY) -->
                <?php if ($isEdit && !empty($images)): ?>
                    <h4>Existing Images</h4>

                    <?php foreach ($images as $img): ?>
                        <div class="room-image">

                            <!-- --- IMAGE THUMBNAIL -->
                            <img src="../assets/amenities/<?= htmlspecialchars(basename($img['image_path'])) ?>">

                            <!-- --- PRIMARY IMAGE RADIO -->
                            <label>
                                <input type="radio"
                                    name="primary_image_id"
                                    value="<?= $img['image_id'] ?>"
                                    <?= $img['is_primary'] ? 'checked' : '' ?>>
                                Primary
                            </label>

                            <!-- --- DELETE IMAGE BUTTON -->
                            <button type="submit"
                                name="action"
                                value="delete_image"
                                class="delete-btn"
                                onclick="return confirm('Delete this image?')">
                                Remove
                            </button>

                            <input type="hidden" name="delete_image_id" value="<?= $img['image_id'] ?>">

                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

                <br><br>

                <!-- --- SUBMIT BUTTON -->
                <button type="submit" class="action-btn"
                    style="background-color:<?= $isEdit ? '#3498db' : '#2ecc71' ?>;color:white;">
                    <?= $isEdit ? 'Save Changes' : 'Add Amenity' ?>
                </button>

                <!-- --- CANCEL BUTTON -->
                <a href="manageAmenities.php" class="action-btn">Cancel</a>

            </form>

        </section>
    </main>
</body>

</html>