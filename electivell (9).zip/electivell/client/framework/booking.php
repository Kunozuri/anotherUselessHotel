<?php
// --- INCLUDE ADMIN DATABASE
include("dbInclude.php");

// -----------------------------
// --- SESSION CHECK (CLEAN VERSION)
// -----------------------------
if (!isset($_SESSION['roomNumber']) || empty($_SESSION['roomNumber'])) {
    // --- USER IS NOT IN BOOKING WORKFLOW
    unset($_SESSION['addedAmenities']);
    unset($_SESSION['lastRoomNumber']);
    $roomId = null;
} else {
    // --- SET CURRENT ROOM ID
    $roomId = (int)$_SESSION['roomNumber'];

    // --- INITIALIZE ADDED AMENITIES SESSION ARRAY IF NOT SET
    if (!isset($_SESSION['addedAmenities'])) {
        $_SESSION['addedAmenities'] = [];
    }

    // --- INITIALIZE LAST ROOM NUMBER SESSION IF NOT SET
    if (!isset($_SESSION['lastRoomNumber'])) {
        $_SESSION['lastRoomNumber'] = $roomId;
    }

    // --- RESET ADDED AMENITIES IF ROOM CHANGED
    if ($_SESSION['lastRoomNumber'] !== $roomId) {
        $_SESSION['addedAmenities'][$roomId] = [];
    }

    // --- UPDATE LAST ROOM NUMBER SESSION
    $_SESSION['lastRoomNumber'] = $roomId;
}

// -----------------------------
// --- FETCH ROOM DATA FROM DATABASE
// -----------------------------
$roomData = null;
$includedAmenities = [];
$additionalAmenities = [];
$roomPrice = 0;
$additionalTotal = 0;
$grandTotal = 0;

if (!empty($roomId)) {

    // --- FETCH ROOM DETAILS FROM DATABASE
    $room = $db->fetchWhere('rooms', ['room_id' => $roomId]);

    if (!empty($room)) {
        $roomData = $room[0];
        $roomPrice = (float)$roomData['price_per_night'];
        $roomType = $roomData['room_type'];
    }

    // --- FETCH INCLUDED AMENITIES (WHERE included = 1)
    $includedAmenities = $db->fetchJoin(
        'room_amenities ra',
        [
            [
                'type' => 'INNER',
                'table' => 'amenities a',
                'on' => 'ra.amenity_id = a.amenity_id',
                'select' => [
                    'amenity_name' => 'a.amenity_name',
                    'amenity_price' => 'a.price'
                ]
            ]
        ],
        [
            'ra.room_id' => $roomId,
            'ra.included' => 1
        ]
    );

    // -----------------------------
    // --- FETCH ADDITIONAL AMENITIES FROM SESSION
    // -----------------------------
    $selectedAmenities = $_SESSION['addedAmenities'][$roomId] ?? [];

    if (!empty($selectedAmenities)) {

        // --- LOOP THROUGH SELECTED AMENITIES
        foreach ($selectedAmenities as $amenityId) {

            // --- FETCH AMENITY DETAILS
            $amenity = $db->fetchWhere('amenities', [
                'amenity_id' => $amenityId,
                'is_active' => 1
            ]);

            // --- ADD TO ADDITIONAL AMENITIES ARRAY AND SUM PRICE
            if (!empty($amenity)) {
                $additionalAmenities[] = $amenity[0];
                $additionalTotal += (float)$amenity[0]['price'];
            }
        }
    }

    // --- INITIALIZE NIGHTS AND ROOM COST
    $nights = 1;
    $roomCost = 0;

    if (!empty($_POST['check_in_date']) && !empty($_POST['check_out_date'])) {

        // --- CALCULATE NUMBER OF NIGHTS BASED ON DATES
        $checkInDate  = new DateTime($_POST['check_in_date']);
        $checkOutDate = new DateTime($_POST['check_out_date']);

        if ($checkOutDate > $checkInDate) {
            $interval = $checkInDate->diff($checkOutDate);
            $nights   = (int)$interval->days;
        }
    }

    // --- CALCULATE ROOM COST AND GRAND TOTAL
    $roomCost   = $roomPrice * $nights;
    $grandTotal = $roomCost + $additionalTotal;
}

// -----------------------------
// --- HANDLE FORM SUBMISSION
// -----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_booking'])) {

    // --- COLLECT FORM DATA SAFELY
    $firstName  = trim($_POST['first_name'] ?? '');
    $middleName = trim($_POST['middle_name'] ?? '');
    $lastName   = trim($_POST['last_name'] ?? '');
    $guestEmail  = trim($_POST['email'] ?? '');
    $guestPhone  = trim($_POST['phone'] ?? '');
    $guestDOB    = $_POST['dob'] ?? '';
    $guestAge    = (int)($_POST['age'] ?? 0);
    $guestAddress = trim($_POST['address'] ?? '');
    $guestCount  = (int)($_POST['guests'] ?? 1);
    $zipCode = trim($_POST['zip_code'] ?? '');
    $city    = trim($_POST['city_or_region'] ?? '');
    $checkIn     = $_POST['check_in_date'] ?? '';
    $checkOut    = $_POST['check_out_date'] ?? '';

    // --- BASIC VALIDATION FOR REQUIRED FIELDS
    if (
        empty($firstName) ||
        empty($lastName) ||
        empty($guestEmail) ||
        empty($guestPhone) ||
        empty($guestDOB) ||
        empty($guestAddress) ||
        empty($zipCode) ||
        empty($city)
    ) {
        $error = "Please fill in all required fields.";
    }

    // --- AGE VALIDATION
    if (!isset($error) && $guestAge < 18) {
        $error = "Guest must be at least 18 years old.";
    }

    // --- DATE VALIDATION
    if (!isset($error)) {

        if (empty($checkIn) || empty($checkOut)) {
            $error = "Please select check-in and check-out dates.";
        } else {

            $checkInDate  = new DateTime($checkIn);
            $checkOutDate = new DateTime($checkOut);

            if ($checkOutDate <= $checkInDate) {
                $error = "Check-out date must be after check-in date.";
            } else {
                $interval = $checkInDate->diff($checkOutDate);
                $nights   = (int)$interval->days;
            }
        }
    }

    // --- CHECK ROOM AVAILABILITY
    if (!isset($error)) {

        $existingReservations = $db->fetchWhere('reservations', [
            'room_id' => $roomId
        ]);

        // --- LOOP THROUGH EXISTING RESERVATIONS TO CHECK CONFLICTS
        foreach ($existingReservations as $reservation) {

            if (!in_array($reservation['reservation_status'], ['Pending', 'Approved'])) {
                continue;
            }

            $existingCheckIn  = new DateTime($reservation['check_in_date']);
            $existingCheckOut = new DateTime($reservation['check_out_date']);

            if ($checkInDate < $existingCheckOut && $checkOutDate > $existingCheckIn) {
                $error = "This room is already booked for the selected dates.";
                break;
            }
        }
    }

    // --- INSERT RESERVATION IF VALID
    if (!isset($error)) {

        // --- GENERATE UNIQUE RESERVATION REFERENCE
        $reservationReference = strtoupper(uniqid("RES"));

        // --- INSERT RESERVATION INTO DATABASE
        $reservationId = $db->insert('reservations', [
            'first_name' => $firstName,
            'middle_name' => $middleName,
            'last_name' => $lastName,
            'email' => $guestEmail,
            'contact_number' => $guestPhone,
            'date_of_birth' => $guestDOB,
            'age' => $guestAge,
            'address' => $guestAddress,
            'zip_code' => $zipCode,
            'city_or_region' => $city,
            'room_id' => $roomId,
            'check_in_date' => $checkIn,
            'check_out_date' => $checkOut,
            'number_of_guests' => $guestCount,
            'nights' => $nights,
            'reservation_reference' => $reservationReference,
            'reservation_status' => 'Pending'
        ]);

        // ----------------------------------
        // --- INSERT ADDITIONAL AMENITIES IF ANY
        // ----------------------------------
        if (!empty($additionalAmenities)) {

            foreach ($additionalAmenities as $amenity) {

                $db->insert('reservation_amenities', [
                    'reservation_id' => $reservationId,
                    'amenity_id' => $amenity['amenity_id'],
                    'quantity' => 1,
                    'price_at_booking' => $amenity['price']
                ]);
            }
        }

        // --- HANDLE FAILURE TO INSERT RESERVATION
        if (!$reservationId) {
            die("Failed to create reservation.");
        }

        // --- STORE RESERVATION ID IN SESSION
        $_SESSION['reservation_id'] = $reservationId;

        // --- CLEAR ADDED AMENITIES FOR THIS ROOM AFTER BOOKING
        unset($_SESSION['addedAmenities'][$roomId]);

        // --- REDIRECT TO PAYMENT PAGE
        header("Location: payment.php");
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- --- META CHARSET UTF-8 -->
    <meta charset="UTF-8">
    <!-- --- PAGE TITLE -->
    <title>Book Your Stay</title>
    <!-- --- LINK TO EXTERNAL CSS -->
    <link rel="stylesheet" href="../design/bookingStyle.css">
</head>

<body>

    <!-- --- RESERVE HERO SECTION -->
    <section class="reserve-hero">
        <h1>Book Your Stay</h1>
        <p>Complete your reservation details below.</p>
    </section>

    <!-- --- RESERVE FORM CONTAINER -->
    <section class="reserve-container">

        <!-- --- RESERVATION FORM -->
        <form id="reservationForm" method="POST">

            <!-- --- RESERVE CARD CONTAINER -->
            <div class="reserve-card">
                <!-- --- DATETIME AVAILABILITY HEADER -->
                <h2>Datetime Availability</h2>

                <!-- --- CHECK-IN AND CHECK-OUT ROW -->
                <div class="form-row">
                    <div class="form-group">
                        <!-- --- CHECK-IN DATE INPUT -->
                        <label>Check-in Date</label>
                        <input type="date" id="checkin" name="check_in_date"
                            value="<?= htmlspecialchars($_POST['check_in_date'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <!-- --- CHECK-OUT DATE INPUT -->
                        <label>Check-out Date</label>
                        <input type="date" id="checkout" name="check_out_date"
                            value="<?= htmlspecialchars($_POST['check_out_date'] ?? '') ?>" required>
                    </div>
                </div>

                <!-- --- GUEST INFORMATION HEADER -->
                <h2>Guest Information</h2>

                <!-- --- DISPLAY ERROR MESSAGE IF EXISTS -->
                <?php if (isset($error)): ?>
                    <p style="color:red;"><?= $error ?></p>
                <?php endif; ?>

                <!-- --- GUEST NAME ROW -->
                <div class="form-row">
                    <div class="form-group">
                        <!-- --- FIRST NAME INPUT -->
                        <label>First Name</label>
                        <input type="text" name="first_name" required>
                    </div>

                    <div class="form-group">
                        <!-- --- MIDDLE NAME INPUT -->
                        <label>Middle Name</label>
                        <input type="text" name="middle_name">
                    </div>

                    <div class="form-group">
                        <!-- --- LAST NAME INPUT -->
                        <label>Last Name</label>
                        <input type="text" name="last_name" required>
                    </div>
                </div>

                <!-- --- EMAIL INPUT -->
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" required>
                </div>

                <!-- --- PHONE NUMBER INPUT -->
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phone" required>
                </div>

                <!-- --- DOB AND AGE ROW -->
                <div class="form-row">
                    <div class="form-group">
                        <!-- --- DATE OF BIRTH INPUT -->
                        <label>Date of Birth</label>
                        <input type="date" id="dob" name="dob" required>
                    </div>

                    <div class="form-group small">
                        <!-- --- AGE INPUT (READONLY) -->
                        <label>Age</label>
                        <input type="text" id="age" name="age" readonly>
                    </div>
                </div>

                <!-- --- ADDRESS INPUT -->
                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address" required></textarea>
                </div>

                <!-- --- ZIP CODE INPUT -->
                <div class="form-group">
                    <label for="zip_code">Zip Code</label>
                    <input type="text" id="zip_code" name="zip_code" required>
                </div>

                <!-- --- CITY/REGION INPUT -->
                <div class="form-group">
                    <label>City / Region</label>
                    <input type="text" name="city_or_region" required>
                </div>

                <!-- --- NUMBER OF GUESTS INPUT -->
                <div class="form-group">
                    <label>Number of Guests</label>
                    <input type="number" name="guests" min="1" max="10" value="2" required>
                </div>

                <!-- --- BOOKING DETAILS HEADER -->
                <h2>Booking Details</h2>

                <!-- --- DISPLAY ROOM TYPE -->
                <p><strong>Room Selected:</strong>
                    <?= htmlspecialchars($roomData['room_type'] ?? 'N/A') ?>
                </p>
                <!-- --- DISPLAY ROOM PRICE -->
                <p><strong>Room Price:</strong> ₱<?= number_format($roomPrice, 2) ?></p>

                <hr>

                <!-- --- INCLUDED AMENITIES LIST -->
                <p><strong>Included Amenities:</strong></p>
                <ul>
                    <?php foreach ($includedAmenities as $amenity): ?>
                        <li>
                            <?= htmlspecialchars($amenity['amenity_name']) ?>
                            (Included)
                        </li>
                    <?php endforeach; ?>
                </ul>

                <!-- --- ADDITIONAL AMENITIES LIST IF ANY -->
                <?php if (!empty($additionalAmenities)): ?>
                    <hr>
                    <p><strong>Additional Amenities:</strong></p>
                    <ul>
                        <?php foreach ($additionalAmenities as $amenity): ?>
                            <li>
                                <?= htmlspecialchars($amenity['amenity_name']) ?>
                                - ₱<?= number_format($amenity['price'], 2) ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <hr>

                <!-- --- COST SUMMARY -->
                <h2>Cost Summary</h2>
                <p><strong>Room Price per Night:</strong> ₱<?= number_format($roomPrice, 2) ?></p>
                <p><strong>Nights:</strong> <?= $nights ?></p>
                <p><strong>Room Cost:</strong> ₱<?= number_format($roomCost, 2) ?></p>
                <p><strong>Additional Amenities:</strong> ₱<?= number_format($additionalTotal, 2) ?></p>

                <!-- --- GRAND TOTAL -->
                <p><strong>Grand Total:</strong>
                    <span style="color:green; font-weight:bold;">
                        ₱<?= number_format($grandTotal, 2) ?>
                    </span>
                </p>

                <!-- --- SUBMIT BUTTON FOR PAYMENT -->
                <button class="confirm-btn" type="submit" name="confirm_booking">
                    Proceed to Payment
                </button>

            </div>
        </form>

    </section>

    <!-- --- JAVASCRIPT FOR AGE CALCULATION AND VALIDATION -->
    <script>
        const dobInput = document.getElementById("dob");
        const ageInput = document.getElementById("age");
        const form = document.getElementById("reservationForm");

        // --- CALCULATE AGE WHEN DOB CHANGES
        dobInput.addEventListener("change", function() {
            const dob = new Date(dobInput.value);
            const today = new Date();
            let age = today.getFullYear() - dob.getFullYear();
            const monthDiff = today.getMonth() - dob.getMonth();

            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
                age--;
            }

            ageInput.value = age;
        });

        // --- VALIDATE AGE BEFORE SUBMITTING FORM
        form.addEventListener("submit", function(e) {
            if (e.submitter && e.submitter.name !== "confirm_booking") {
                return;
            }

            if (ageInput.value === "" || ageInput.value < 18) {
                e.preventDefault();
                alert("Guest must be at least 18 years old.");
            }
        });
    </script>

    <!-- --- JAVASCRIPT FOR DATE REFRESH TO CALCULATE TOTAL -->
    <script>
        const checkinInput = document.getElementById("checkin");
        const checkoutInput = document.getElementById("checkout");

        function refreshForTotal() {

            if (checkinInput.value && checkoutInput.value) {

                // --- CREATE HIDDEN INPUT TO INDICATE DATE REFRESH
                let refreshInput = document.createElement("input");
                refreshInput.type = "hidden";
                refreshInput.name = "date_refresh";
                refreshInput.value = "1";

                form.appendChild(refreshInput);

                // --- SUBMIT FORM TO REFRESH TOTAL
                form.submit();
            }
        }

        checkinInput.addEventListener("change", refreshForTotal);
        checkoutInput.addEventListener("change", refreshForTotal);
    </script>

</body>

</html>