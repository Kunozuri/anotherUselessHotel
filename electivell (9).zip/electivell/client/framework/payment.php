<?php
// --- INCLUDE DATABASE CONNECTION AND REQUIRED FILES
include("dbInclude.php");

// --- CHECK IF RESERVATION SESSION EXISTS
if (!isset($_SESSION['reservation_id'])) {
    // --- REDIRECT TO BOOKING PAGE IF SESSION NOT SET
    header("Location: booking.php");
    exit;
}

// --- CAST RESERVATION ID TO INTEGER FOR SECURITY
$reservationId = (int)$_SESSION['reservation_id'];

// --- FETCH RESERVATION DATA FROM DATABASE
$reservation = $db->fetchWhere('reservations', [
    'reservation_id' => $reservationId
]);

// --- IF NO RESERVATION FOUND, REDIRECT TO BOOKING PAGE
if (empty($reservation)) {
    header("Location: booking.php");
    exit;
}

// --- STORE FIRST RESULT ROW
$reservation = $reservation[0];

// --- FETCH ROOM DETAILS BASED ON RESERVATION
$room = $db->fetchWhere('rooms', [
    'room_id' => $reservation['room_id']
]);

// --- SET ROOM TYPE AND PRICE WITH DEFAULT FALLBACK VALUES
$roomType = $room[0]['room_type'] ?? 'N/A';
$roomPrice = $room[0]['price_per_night'] ?? 0;

// --- FETCH INCLUDED AMENITIES USING INNER JOIN
$includedAmenities = $db->fetchJoin(
    'room_amenities ra',
    [
        [
            'type' => 'INNER',
            'table' => 'amenities a',
            'on' => 'ra.amenity_id = a.amenity_id',
            'select' => [
                'amenity_name' => 'a.amenity_name'
            ]
        ]
    ],
    [
        'ra.room_id' => $reservation['room_id'],
        'ra.included' => 1
    ]
);

// --- FETCH ADDITIONAL AMENITIES SELECTED DURING RESERVATION
$additionalAmenities = $db->fetchJoin(
    'reservation_amenities rma',
    [
        [
            'type' => 'INNER',
            'table' => 'amenities a',
            'on' => 'rma.amenity_id = a.amenity_id',
            'select' => [
                'amenity_name' => 'a.amenity_name',
                'price_at_booking' => 'rma.price_at_booking'
            ]
        ]
    ],
    [
        'rma.reservation_id' => $reservationId
    ]
);

// --- CALCULATE TOTAL ROOM COST
$roomCost = $roomPrice * $reservation['nights'];

// --- INITIALIZE ADDITIONAL AMENITIES TOTAL
$additionalTotal = 0;

// --- LOOP THROUGH ADDITIONAL AMENITIES TO SUM TOTAL COST
foreach ($additionalAmenities as $amenity) {
    $additionalTotal += $amenity['price_at_booking'];
}

// --- CALCULATE GRAND TOTAL COST
$grandTotal = $roomCost + $additionalTotal;
?>

<!DOCTYPE html>
<html>

<head>
    <!-- SET PAGE TITLE -->
    <title>Reservation Receipt</title>
    <!-- LINK EXTERNAL STYLESHEET -->
    <link rel="stylesheet" href="../design/bookingStyle.css">
</head>

<body>

    <!-- RESERVATION HEADER SECTION -->
    <section class="reserve-hero">
        <h1>Reservation Receipt</h1>
        <p>Review your booking before payment.</p>
    </section>

    <!-- MAIN RESERVATION CONTAINER -->
    <section class="reserve-container">
        <div class="reserve-card">

            <!-- RESERVATION DETAILS SECTION -->
            <h2>Reservation Details</h2>

            <p><strong>Reference:</strong> <?= htmlspecialchars($reservation['reservation_reference']) ?></p>
            <p><strong>Room Type:</strong> <?= htmlspecialchars($roomType) ?></p>
            <p><strong>Check-in:</strong> <?= htmlspecialchars($reservation['check_in_date']) ?></p>
            <p><strong>Check-out:</strong> <?= htmlspecialchars($reservation['check_out_date']) ?></p>
            <p><strong>Nights:</strong> <?= $reservation['nights'] ?></p>

            <hr>

            <!-- INCLUDED AMENITIES LIST -->
            <h3>Included Amenities</h3>
            <ul>
                <?php foreach ($includedAmenities as $amenity): ?>
                    <!-- DISPLAY EACH INCLUDED AMENITY -->
                    <li><?= htmlspecialchars($amenity['amenity_name']) ?> (Included)</li>
                <?php endforeach; ?>
            </ul>

            <?php if (!empty($additionalAmenities)): ?>
                <hr>
                <!-- ADDITIONAL AMENITIES SECTION -->
                <h3>Additional Amenities</h3>
                <ul>
                    <?php foreach ($additionalAmenities as $amenity): ?>
                        <!-- DISPLAY EACH ADDITIONAL AMENITY WITH PRICE -->
                        <li>
                            <?= htmlspecialchars($amenity['amenity_name']) ?>
                            - ₱<?= number_format($amenity['price_at_booking'], 2) ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <hr>

            <!-- COST SUMMARY SECTION -->
            <h2>Cost Summary</h2>
            <p>Room Cost: ₱<?= number_format($roomCost, 2) ?></p>
            <p>Additional Amenities: ₱<?= number_format($additionalTotal, 2) ?></p>
            <p style="color:green; font-weight:bold;">
                Grand Total: ₱<?= number_format($grandTotal, 2) ?>
            </p>

            <hr>

            <!-- PRINT RECEIPT BUTTON -->
            <button class="confirm-btn" onclick="window.print()">
                Print Receipt
            </button>

        </div>
    </section>

</body>

</html>