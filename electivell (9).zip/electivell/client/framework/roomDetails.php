<?php
// --- INCLUDE HEADER FILE
include("header.php");

// --- SESSION CHECK
if (!isset($_SESSION['roomNumber']) || empty($_SESSION['roomNumber'])) {
    // --- RESET ADDED AMENITIES AND LAST ROOM IF NO ROOM SELECTED
    unset($_SESSION['addedAmenities']);
    unset($_SESSION['lastRoomNumber']);
    // --- REDIRECT TO ROOM SELECTION PAGE
    header("Location: room.php");
    exit;
}

// --- SET CURRENT ROOM ID
$roomId = (int)$_SESSION['roomNumber'];

// --- INITIALIZE ADDED AMENITIES IF NOT SET
if (!isset($_SESSION['addedAmenities'])) {
    $_SESSION['addedAmenities'] = [];
}

// --- INITIALIZE LAST ROOM NUMBER IF NOT SET
if (!isset($_SESSION['lastRoomNumber'])) {
    $_SESSION['lastRoomNumber'] = $roomId;
}

// --- RESET AMENITIES IF USER SWITCHED ROOMS
if ($_SESSION['lastRoomNumber'] !== $roomId) {
    $_SESSION['addedAmenities'][$roomId] = [];
}

// --- UPDATE LAST VISITED ROOM
$_SESSION['lastRoomNumber'] = $roomId;

// --- HANDLE REMOVE AMENITY BUTTON CLICK
if (isset($_POST['remove-amenity'])) {
    $removeId = (int)$_POST['amenity_id'];
    if (($key = array_search($removeId, $_SESSION['addedAmenities'][$roomId])) !== false) {
        unset($_SESSION['addedAmenities'][$roomId][$key]);
    }
    // --- REINDEX ADDED AMENITIES ARRAY
    $_SESSION['addedAmenities'][$roomId] = array_values($_SESSION['addedAmenities'][$roomId]);
    header("Location: roomDetails.php");
    exit;
}

// --- FETCH ROOM DATA
$roomResult = $db->fetchWhere('rooms', ['room_id' => $roomId]);

if (!$roomResult) {
    // --- REDIRECT IF ROOM NOT FOUND
    header("Location: room.php");
    exit;
}

$roomData = $roomResult[0];

// --- FETCH ROOM IMAGES (PRIMARY IMAGE FIRST)
$roomImages = $db->fetchWhere('room_images', ['room_id' => $roomId]);

usort($roomImages, function ($a, $b) {
    return $b['is_primary'] <=> $a['is_primary'];
});

$roomData['images'] = [];
foreach ($roomImages as $img) {
    $roomData['images'][] = $img['image_path'];
}

// --- USE DEFAULT IMAGE IF NO ROOM IMAGES
if (empty($roomData['images'])) {
    $roomData['images'][] = "/assets/rooms/default.jpg";
}

// --- FETCH INCLUDED AMENITIES FOR ROOM
$amenityRows = $db->fetchWhere('room_amenities', ['room_id' => $roomId]);

$roomData['amenities'] = [];
foreach ($amenityRows as $ra) {
    if ($ra['included']) {
        $amenity = $db->fetchWhere('amenities', [
            'amenity_id' => $ra['amenity_id'],
            'is_active'  => 1
        ]);
        if ($amenity) {
            $roomData['amenities'][] = $amenity[0]['amenity_name'];
        }
    }
}

// --- FETCH ADDED ADDITIONAL AMENITIES FOR THIS ROOM
$addedAmenityIds = $_SESSION['addedAmenities'][$roomId] ?? [];
$addedAmenities = [];
foreach ($addedAmenityIds as $amenityId) {
    $amenity = $db->fetchWhere('amenities', [
        'amenity_id' => $amenityId,
        'is_active'  => 1
    ]);
    if ($amenity) {
        $addedAmenities[] = $amenity[0];
    }
}

// --- HANDLE ADD AMENITY BUTTON
if (isset($_POST['add-amenity'])) {
    $_SESSION['roomNumber'] = $roomId;
    header("Location: amenity.php");
    exit;
}

// --- HANDLE BOOK NOW BUTTON
if (isset($_POST['book-now'])) {
    $_SESSION['roomNumber'] = $roomId;
    $_SESSION['addedAmenity'] = $_SESSION['addedAmenities'][$roomId] ?? [];
    header("Location: booking.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- --- PAGE META CHARSET -->
    <meta charset="UTF-8">
    <!-- --- PAGE TITLE -->
    <title><?= htmlspecialchars($roomData['room_type']) ?> Details</title>
    <!-- --- LINK STYLESHEET -->
    <link rel="stylesheet" href="../design/roomDetailStyle.css">
</head>
<body>

<!-- --- ROOM TYPE HEADING -->
<h1><?= htmlspecialchars($roomData['room_type']) ?></h1>

<!-- --- ROOM IMAGES -->
<div class="room-images">
    <?php foreach ($roomData['images'] as $img): ?>
        <img src="/electivell/admin<?= htmlspecialchars($img) ?>" alt="Room Image">
    <?php endforeach; ?>
</div>

<!-- --- ROOM DETAILS SECTION -->
<div class="room-details">

    <!-- --- ROOM DESCRIPTION -->
    <h2>Description</h2>
    <p><?= nl2br(htmlspecialchars($roomData['description'])) ?></p>

    <!-- --- ROOM PRICE -->
    <h2>Price</h2>
    <p>₱<?= number_format($roomData['price_per_night'], 2) ?> per night</p>

    <!-- --- INCLUDED AMENITIES LIST -->
    <h2>Included Amenities</h2>
    <?php if (!empty($roomData['amenities'])): ?>
        <ul>
            <?php foreach ($roomData['amenities'] as $amenity): ?>
                <li><?= htmlspecialchars($amenity) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No amenities included.</p>
    <?php endif; ?>

    <!-- --- ADDITIONAL AMENITIES LIST -->
    <h2>Additional Amenities</h2>
    <?php if (!empty($addedAmenities)): ?>
        <ul>
            <?php foreach ($addedAmenities as $amenity): ?>
                <li>
                    <?= htmlspecialchars($amenity['amenity_name']) ?> -
                    $<?= number_format($amenity['price'], 2) ?>
                    <!-- --- REMOVE AMENITY BUTTON -->
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="amenity_id" value="<?= $amenity['amenity_id'] ?>">
                        <button type="submit" name="remove-amenity">Remove</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No additional amenities added.</p>
    <?php endif; ?>

    <!-- --- ACTION BUTTONS: ADD AMENITY / BOOK NOW -->
    <div class="buttons">
        <form method="POST" style="display:inline;">
            <button type="submit" name="add-amenity" class="add-amenity">Add Amenity</button>
        </form>

        <form method="POST" style="display:inline;">
            <?php
            foreach ($addedAmenities as $amenity) {
                echo '<input type="hidden" name="amenities[]" value="' . $amenity['amenity_id'] . '">';
            }
            ?>
            <button type="submit" name="book-now" class="btn-book">Book Now</button>
        </form>
    </div>
</div>
</body>
</html>

<!-- --- INCLUDE FOOTER FILE -->
<?php include("footer.html"); ?>