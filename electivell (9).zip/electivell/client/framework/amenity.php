<?php
// --- INCLUDE HEADER FILE
include("header.php");

// --- SESSION CHECK
if (!isset($_SESSION['roomNumber']) || empty($_SESSION['roomNumber'])) {
    // --- RESET ADDED AMENITIES IF NO ROOM SELECTED
    unset($_SESSION['addedAmenities']);
    unset($_SESSION['lastRoomNumber']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- --- PAGE META CHARSET -->
    <meta charset="UTF-8">
    <!-- --- PAGE VIEWPORT SETTINGS -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- --- PAGE TITLE -->
    <title>Our Amenities</title>
    <!-- --- LINK STYLESHEET -->
    <link rel="stylesheet" href="../design/amenityStyle.css">
</head>

<body>

    <!-- --- AMENITY SECTION START -->
    <section class="amenity-section">

        <!-- --- AMENITY HEADER -->
        <div class="amenity-header">
            <h1>Our Amenities</h1>
            <p>Discover premium features designed to enhance your comfort and elevate your stay experience.</p>
        </div>

        <!-- --- AMENITY SCROLL CONTAINER -->
        <div class="amenity-scroll">

            <?php
            // --- GET ALL AMENITIES FROM DATABASE
            if (isset($_SESSION['roomNumber']) && !empty($_SESSION['roomNumber'])) {

                // --- GET CURRENT ROOM ID
                $roomId = (int)$_SESSION['roomNumber'];

                // --- FETCH AMENITIES LEFT JOIN ROOM AMENITIES
                $amenities = $db->fetchJoin(
                    "amenities a",
                    [
                        [
                            "type" => "LEFT",
                            "table" => "room_amenities ra",
                            "on" => "a.amenity_id = ra.amenity_id 
                         AND ra.room_id = $roomId 
                         AND ra.included = 1"
                        ]
                    ],
                    [
                        "a.is_active" => 1,
                        "ra.amenity_id" => "NULL"
                    ],
                    "AND"
                );

                // --- REMOVE ALREADY ADDED ADDITIONAL AMENITIES
                $alreadyAdded = $_SESSION['addedAmenities'][$roomId] ?? [];

                if (!empty($alreadyAdded)) {
                    $amenities = array_filter($amenities, function ($amenity) use ($alreadyAdded) {
                        return !in_array($amenity['amenity_id'], $alreadyAdded);
                    });

                    // --- REINDEX AMENITY ARRAY
                    $amenities = array_values($amenities);
                }
            } else {
                // --- FETCH ALL ACTIVE AMENITIES IF NO ROOM SELECTED
                $amenities = $db->fetchWhere("amenities", ["is_active" => 1]);
            }

            // --- HANDLE VIEW DETAILS BUTTON CLICK
            if (isset($_POST['view-details'])) {
                $_SESSION['amenityNumber'] = (int)$_POST['amenityNumber'];
                if (isset($_POST['roomNumber'])) {
                    $_SESSION['roomNumber'] = (int)$_POST['roomNumber'];
                }
                // --- REDIRECT TO AMENITY DETAILS PAGE
                header("Location: amenityDetails.php");
                exit;
            }

            // --- RENDER AMENITY CARDS
            foreach ($amenities as $amenityData) {
                renderAmenityCard($amenityData, $db);
            }
            ?>

        </div>
    </section>

</body>

</html>

<!-- --- INCLUDE FOOTER FILE -->
<?php include("footer.html"); ?>

<?php
// --- FUNCTION TO RENDER SINGLE AMENITY CARD
function renderAmenityCard(array $amenityData, Database $db)
{
    // --- FETCH ALL IMAGES FOR THIS AMENITY
    $amenityImages = $db->fetchWhere('amenity_images', ['amenity_id' => $amenityData['amenity_id']]);

    // --- SORT IMAGES BY PRIMARY FLAG
    usort($amenityImages, function ($a, $b) {
        return $b['is_primary'] <=> $a['is_primary'];
    });
?>
    <!-- --- AMENITY CARD CONTAINER -->
    <div class="amenity-card">

        <!-- --- AMENITY IMAGES -->
        <div class="amenity-images">
            <?php foreach ($amenityImages as $img): ?>
                <!-- --- AMENITY IMAGE ELEMENT -->
                <img src="/electivell/admin/<?= htmlspecialchars($img['image_path']) ?>"
                    alt="<?= htmlspecialchars($amenityData['amenity_name']) ?> IMAGE">
            <?php endforeach; ?>
        </div>

        <!-- --- AMENITY NAME -->
        <h3><?= htmlspecialchars($amenityData['amenity_name']) ?></h3>

        <!-- --- AMENITY DESCRIPTION -->
        <p class="amenity-desc"><?= htmlspecialchars($amenityData['description']) ?></p>

        <!-- --- AMENITY PRICE -->
        <p class="amenity-price">
            $<?= number_format($amenityData['price'], 2) ?>
        </p>

        <!-- --- DETAILS BUTTON -->
        <form method="POST">
            <input type="hidden" name="amenityNumber" value="<?= $amenityData['amenity_id'] ?>">
            <?php if (isset($_SESSION['roomNumber'])): ?>
                <input type="hidden" name="roomNumber" value="<?= $_SESSION['roomNumber'] ?>">
            <?php endif; ?>
            <button type="submit" name="view-details" class="room-btn">VIEW DETAILS</button>
        </form>

    </div>
<?php
}
?>